#ifndef GBKUTILS_H
#define GBKUTILS_H

#include "qglobal.h"
#include <QByteArray>

class GBKUtils
{
public:
    GBKUtils();
    void loadGBK16Array();
    char* toGBKEncoding(QString& str);
    void createMatrixFont(QString& oneChar, quint8 (*toArray)[40], quint8 startPos, bool isModeNormal);
    void createHexFont(QString& oneChar,quint8 *toArray,bool isReverse);
    int getGBKAddress(QString& str);
    int getGBK16Range(int areaCode,int posCode);
private:
    QByteArray charArr;
};

#endif // GBKUTILS_H
