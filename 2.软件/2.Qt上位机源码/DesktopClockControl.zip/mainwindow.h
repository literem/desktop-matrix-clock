#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <serialdialog.h>
#include <displaystaticdialog.h>
#include <displayscrolldialog.h>
#include <displayclockdialog.h>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void SwitchToSerialDialog();
    void SwitchToStaticDialog();
    void SwitchToScrollDialog();
    void SwitchToClockDialog();

    void receiveTest();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
