#ifndef SENDDATATRANSFER_H
#define SENDDATATRANSFER_H

#include <QtGlobal>
#include <QList>

#include "send_data_array.h"

class SendDataTransfer
{
public:
    static SendDataArray* createStartFrame(quint8 cmd,quint8 frameCount,quint8 frameID,quint16 frameLen);
    static SendDataArray* createOneFrame(quint8* dat,quint16 datLen,quint8 frameID,quint8 frameCount,quint8 frameIndex);
    static QList<SendDataArray*>* createFrame(quint8* dat,quint16 len,quint8 cmd,quint16 payloadSize);
    static SendDataArray* createCommand(quint8 cmd,quint32 dat);
};

#endif // SENDDATATRANSFER_H
