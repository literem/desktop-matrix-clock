#ifndef MATRIX_COMMAND_H
#define MATRIX_COMMAND_H

//命令/数据标志位
#define BIT3_DAT        0xA1
#define BIT3_CMD        0xA2
#define BIT3_REQUEST    0xA3
#define BIT3_FINISH     0xA4
#define FRAME_PART		0xA5

#define CMD_CUSTOM      0xC0 //自由显示
#define CMD_SCROLL      0xC1 //滚动显示
#define CMD_CLOCK       0xC2 //时钟显示
#define CMD_TIMING_2    0xC3 //计时显示（分秒）
#define CMD_TIMING_3    0xC4 //计时显示（时分秒）
#define CMD_COUNTDOWN_2 0xC5 //倒计时显示（分秒）
#define CMD_COUNTDOWN_3 0xC6 //倒计时显示（时分秒）
#define CMD_SPEED       0xC7 //设置速度
#define CMD_ANIM        0xC8 //设置动画



#endif // MATRIX_COMMAND_H
