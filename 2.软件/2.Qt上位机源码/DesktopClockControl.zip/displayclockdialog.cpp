#include "displayclockdialog.h"
#include "ui_displayclockdialog.h"

#include <QMessageBox>
#include <QDebug>

#include "send_data_transfer.h"
#include "matrix_command.h"

#define CLOCK_MMSS     0
#define CLOCK_HHMM     1
#define CLOCK_HHMMSS   2

#define CLOCK_ANIM_NONE 0
#define CLOCK_ANIM_UP   1
#define CLOCK_ANIM_DOWN 2

QString displayCheckStyle = "background:rgb(238, 238, 238);border-radius:10px;color:rgb(48, 48, 48);border:1px solid rgb(0, 0, 0);";
QString displayUncheckStyle = "background:rgb(238, 238, 238);border-radius:10px;color:rgb(48, 48, 48);";

DisplayClockDialog::DisplayClockDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DisplayClockDialog)
{
    ui->setupUi(this);
    ui->editCountdownSecond->setInputMask("99");
    ui->editCountdownMinute->setInputMask("99");
    ui->editTimingSecond->setInputMask("99");
    ui->editTimingMinute->setInputMask("99");
    ui->radioButtonNoneAnim->setChecked(true);
    displayMode = CLOCK_HHMM;
    timingMode = CLOCK_MMSS;
    countdownMode = CLOCK_MMSS;
    ui->editTimingHour->setVisible(false);
    ui->labelTimingHour->setVisible(false);
    ui->editCountdownHour->setVisible(false);
    ui->labelCountdownHour->setVisible(false);
}

DisplayClockDialog::~DisplayClockDialog()
{
    delete ui;
}


void DisplayClockDialog::on_buttonHMdisplay_clicked()
{
    if(displayMode == CLOCK_HHMM) return;
    displayMode = CLOCK_HHMM;
    ui->buttonHMdisplay->setStyleSheet(displayCheckStyle);
    ui->buttonHMSdisplay->setStyleSheet(displayUncheckStyle);
}

void DisplayClockDialog::on_buttonHMSdisplay_clicked()
{
    if(displayMode == CLOCK_HHMMSS) return;
    displayMode = CLOCK_HHMMSS;
    ui->buttonHMSdisplay->setStyleSheet(displayCheckStyle);
    ui->buttonHMdisplay->setStyleSheet(displayUncheckStyle);
}


void DisplayClockDialog::on_buttonClockSetting_clicked()
{
    quint32 value = (displayMode == CLOCK_HHMM) ? CLOCK_HHMM : CLOCK_HHMMSS;
    SendDataArray* sda = SendDataTransfer::createCommand(CMD_CLOCK,value);

    if(list.size() != 0) list.clear();
    list.append(sda);
    emit sendSerialData(&list);
}


void DisplayClockDialog::on_buttonTimingSetting_clicked()
{
    bool result;
    QString strHour = ui->editTimingHour->text();
    QString strMinute = ui->editTimingMinute->text();
    QString strSecond = ui->editTimingSecond->text();
    int hour = 0;
    int minute = strMinute.toInt(&result);
    int second = strSecond.toInt(&result);
    if(timingMode == CLOCK_MMSS)
    {
        if(minute == 99 && second >= 59)
        {
            QMessageBox::warning(this,"提示","计时时间超出范围，请输入有意义的时间");
            return;
        }
    }
    else
    {
        hour = strHour.toInt(&result);
        if(hour == 99 && minute >= 59 && second >= 59)
        {
            QMessageBox::warning(this,"提示","计时时间超出范围，请输入有意义的时间");
            return;
        }
        if(minute > 59)
        {
            minute = 59;
            ui->editTimingMinute->setText(QString::number(59));
        }
    }

    if(result == false)
    {
        QMessageBox::warning(this,"提示","请输入正确的时间");
        return;
    }
    if(second > 59)
    {
        second = 59;
        ui->editTimingSecond->setText(QString::number(59));
    }

    if(list.size() != 0) list.clear();
    quint8 cmd = (timingMode == CLOCK_MMSS) ? CMD_TIMING_2 : CMD_TIMING_3;
    quint32 value = (hour << 16 ) + (minute << 8) + second;
    SendDataArray* sda = SendDataTransfer::createCommand(cmd,value);
    list.append(sda);
    emit sendSerialData(&list);
}

void DisplayClockDialog::on_buttonCountdownSetting_clicked()
{
    bool result;
    QString strHour = ui->editCountdownHour->text();
    QString strMinute = ui->editCountdownMinute->text();
    QString strSecond = ui->editCountdownSecond->text();
    int hour = 0;
    int minute = strMinute.toInt(&result);
    int second = strSecond.toInt(&result);
    if(countdownMode == CLOCK_MMSS)
    {
        if(minute == 99 && second >= 59)
        {
            QMessageBox::warning(this,"提示","计时时间超出范围，请输入有意义的时间");
            return;
        }
    }
    else
    {
        hour = strHour.toInt(&result);
        if(hour == 99 && minute >= 59 && second >= 59)
        {
            QMessageBox::warning(this,"提示","计时时间超出范围，请输入有意义的时间");
            return;
        }
        if(minute > 59)
        {
            minute = 59;
            ui->editCountdownMinute->setText(QString::number(59));
        }
    }

    if(result == false)
    {
        QMessageBox::warning(this,"提示","请输入正确的时间");
        return;
    }
    if(second > 59)
    {
        second = 59;
        ui->editCountdownSecond->setText(QString::number(59));
    }

    if(list.size() != 0) list.clear();
    quint8 cmd = (countdownMode == CLOCK_MMSS) ? CMD_COUNTDOWN_2 : CMD_COUNTDOWN_3;
    quint32 value = (hour << 16 ) + (minute << 8) + second;
    SendDataArray* sda = SendDataTransfer::createCommand(cmd,value);
    list.append(sda);
    emit sendSerialData(&list);
}

void DisplayClockDialog::on_buttonAnimSetting_clicked()
{
    quint32 value = 0;
    if(ui->radioButtonNoneAnim->isChecked()) value = CLOCK_ANIM_NONE;
    else if(ui->radioButtonUpAnim->isChecked()) value = CLOCK_ANIM_UP;
    else if(ui->radioButtonDownAnim->isChecked()) value = CLOCK_ANIM_DOWN;

    if(list.size() != 0) list.clear();
    SendDataArray* sda = SendDataTransfer::createCommand(CMD_ANIM,value << 16);
    list.append(sda);
    emit sendSerialData(&list);
}


void DisplayClockDialog::on_buttonMSTiming_clicked()
{
    if(timingMode == CLOCK_MMSS) return;
    timingMode = CLOCK_MMSS;
    ui->buttonMSTiming->setStyleSheet(displayCheckStyle);
    ui->buttonHMSTiming->setStyleSheet(displayUncheckStyle);
    ui->editTimingHour->setVisible(false);
    ui->labelTimingHour->setVisible(false);
}


void DisplayClockDialog::on_buttonHMSTiming_clicked()
{
    if(timingMode == CLOCK_HHMMSS) return;
    timingMode = CLOCK_HHMMSS;
    ui->buttonHMSTiming->setStyleSheet(displayCheckStyle);
    ui->buttonMSTiming->setStyleSheet(displayUncheckStyle);
    ui->editTimingHour->setVisible(true);
    ui->labelTimingHour->setVisible(true);
}


void DisplayClockDialog::on_buttonMSCountDown_clicked()
{
    if(countdownMode == CLOCK_MMSS) return;
    countdownMode = CLOCK_MMSS;
    ui->buttonMSCountDown->setStyleSheet(displayCheckStyle);
    ui->buttonHMSCountDown->setStyleSheet(displayUncheckStyle);
    ui->editCountdownHour->setVisible(false);
    ui->labelCountdownHour->setVisible(false);
}


void DisplayClockDialog::on_buttonHMSCountDown_clicked()
{
    if(countdownMode == CLOCK_HHMMSS) return;
    countdownMode = CLOCK_HHMMSS;
    ui->buttonHMSCountDown->setStyleSheet(displayCheckStyle);
    ui->buttonMSCountDown->setStyleSheet(displayUncheckStyle);
    ui->editCountdownHour->setVisible(true);
    ui->labelCountdownHour->setVisible(true);
}

