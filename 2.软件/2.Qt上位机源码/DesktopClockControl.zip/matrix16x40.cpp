#include "matrix16x40.h"
#include "ui_matrix16x40.h"

//一共有16行，每行有40个bit
quint8 buff[16][40];

Matrix16x40::Matrix16x40(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Matrix16x40)
{
    ui->setupUi(this);
    int i,j;
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 40; j++) {
            buff[i][j]=0;
        }
    }
}

Matrix16x40::~Matrix16x40()
{
    delete ui;
}

quint8 *Matrix16x40::getBuff()
{
    return (quint8 *)buff;
}

void Matrix16x40::createHex(quint8 **result)
{
    quint8 *array = *result;
    int i,j;
    int pos=0;
    for(i=0;i<16;i++)
    {
        for(j=0;j<5;j++,pos++)
        {
            array[pos] = binToHex(i,j*8);
        }
    }
}

quint8 Matrix16x40::binToHex(quint8 y, quint8 x)
{
    quint8 m = 128,result = 0;
    for(quint8 k=0;k<8;k++,x++,m>>=1)
    {
        if(buff[y][x]==0) result+=m;
    }
    return result;
}

void Matrix16x40::setBuff(int x, int y,quint8 v)
{
    buff[x][y] = v;
}

void Matrix16x40::cleanBuff()
{
    int i,j;
    for (i = 0; i < 16; i++) {
        for (j = 0; j < 40; j++) {
            buff[i][j] = 0;
        }
    }
}

void Matrix16x40::refresh()
{
    update();
}

void Matrix16x40::shiftLeft()
{
    int i,j;
    for(i=0;i<16;i++)
    {
        for(j=1;j<40;j++)
        {
            buff[i][j-1] = buff[i][j];
        }
        buff[i][39] = 0;
    }
    update();
}

void Matrix16x40::shiftRight()
{
    int i,j;
    for(i=0;i<16;i++)
    {
        for(j=39;j>0;j--)
        {
            buff[i][j] = buff[i][j-1];
        }
        buff[i][0] = 0;
    }
    update();
}

void Matrix16x40::paintEvent(QPaintEvent *event)
{
    int i,j;
    int startX,startY;

    QPainter painter(this);
    painter.setBrush(QBrush(QColor(0,0,0)));
    painter.drawRoundedRect(QRect(0,0,608,245),10,10);

    painter.setPen(QColor(255, 0, 0));
    painter.setBrush(QBrush(QColor(255, 0, 0)));
    for(i=0,startY=START_Y;i<16;i++,startY+=PADDING_Y)
    {
        for(j=0,startX=START_X;j<40;j++,startX+=PADDING_X)
        {
            if(buff[i][j] == 1)
            {
                painter.drawEllipse(startX,startY,RADIUS,RADIUS);
            }
        }
    }

    painter.setPen(QColor(198, 198, 198));
    painter.setBrush(QBrush(QColor(198, 198, 198)));
    for(i=0,startY=START_Y;i<16;i++,startY+=PADDING_Y)
    {
        for(j=0,startX=START_X;j<40;j++,startX+=PADDING_X)
        {
            if(buff[i][j] == 0)
            {
                painter.drawEllipse(startX,startY,RADIUS,RADIUS);
            }
        }
    }
}


void Matrix16x40::mousePressEvent(QMouseEvent *e)
{

    if(e->buttons() != Qt::LeftButton) return;
    QPointF pressQPoint = e->localPos();

    int x = pressQPoint.x();
    int y = pressQPoint.y();
    if(x > 4 && x < 600 && y > 4 && y < 240)
    {
        x = x / 15;
        y = y / 15;
        buff[y][x] = !buff[y][x];
        update();
    }

    qDebug() << "鼠标按下,pos="<<pressQPoint << ",x:" << x << ",y:" << y;
}

void Matrix16x40::mouseMoveEvent(QMouseEvent *e)
{
    if(e->buttons() != Qt::LeftButton) return;
    QPointF last_pos = e->localPos();
    qDebug()<<"last_pos:"<<last_pos;
}

void Matrix16x40::mouseReleaseEvent(QMouseEvent *e)
{
    if(e->buttons() != Qt::LeftButton) return;
    qDebug() << "鼠标松开了\n";
}

