#include "displayscrolldialog.h"
#include "ui_displayscrolldialog.h"

#include <QDebug>
#include <QMessageBox>
#include "gbk_utils.h"
#include "matrix_command.h"

int scrollSpeed = 300;

DisplayScrollDialog::DisplayScrollDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DisplayScrollDialog)
{
    ui->setupUi(this);
}

DisplayScrollDialog::~DisplayScrollDialog()
{
    delete ui;
}


QString printHex(quint8 *dat,int len)
{
    QString text;

    for (int j = 0; j < len; ++j) {
        text += QString::number(dat[j],16) += " ";
    }
    text+="\n";
    return text;
}


void DisplayScrollDialog::on_horizontalSlider_valueChanged(int value)
{
    scrollSpeed = value;
    ui->labelSpeed->setText(QString::number(value) + " ms");
}

void DisplayScrollDialog::on_buttonSetScroll_clicked()
{
    QString strdata = ui->scrollTextInput->text();

    int len = strdata.size();
    if(len == 0)
    {
        QMessageBox::warning(this,"提示","请输入内容");
        return;
    }
    if(len < 1)
    {
        QMessageBox::warning(this,"提示","输入的字符要大于3才能滚动");
        return;
    }
    GBKUtils utils = GBKUtils();
    quint8 array[len*32];
    bool isReverse = ui->checkBoxReverse->isChecked();
    for(int i=0;i<len;i++)
    {
        QString str = QString(strdata.at(i));
        utils.createHexFont(str,&array[i*32],isReverse);
    }
    QList<SendDataArray*> *list = SendDataTransfer::createFrame(array,len*32,CMD_SCROLL,64);

    emit sendSerialData(list);

    for (int i = 0; i < list->size(); ++i) {
        SendDataArray* sda = list->at(i);
        ui->plainTextEdit->appendPlainText(printHex(sda->array,sda->arraySize));
    }
}


void DisplayScrollDialog::on_buttonSetSpeed_clicked()
{
    quint16 value = ui->horizontalSlider->value();
    value = value < 100 ? 500 : value;
    QList<SendDataArray*> list;
    SendDataArray* sda = SendDataTransfer::createCommand(CMD_SPEED,value << 16);
    list.append(sda);
    emit sendSerialData(&list);
}


void DisplayScrollDialog::on_buttonClearPreview_clicked()
{
    ui->plainTextEdit->clear();
}

