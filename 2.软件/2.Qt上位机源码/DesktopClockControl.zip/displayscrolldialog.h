#ifndef DISPLAYSCROLLDIALOG_H
#define DISPLAYSCROLLDIALOG_H

#include "send_data_array.h"
#include "send_data_transfer.h"

#include <QDialog>
#include <QList>

namespace Ui {
class DisplayScrollDialog;
}

class DisplayScrollDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DisplayScrollDialog(QWidget *parent = nullptr);
    ~DisplayScrollDialog();

Q_SIGNALS:
    void sendSerialData(QList<SendDataArray*> *list);

private slots:

    void on_horizontalSlider_valueChanged(int value);

    void on_buttonSetScroll_clicked();

    void on_buttonSetSpeed_clicked();

    void on_buttonClearPreview_clicked();

private:
    Ui::DisplayScrollDialog *ui;
};

#endif // DISPLAYSCROLLDIALOG_H
