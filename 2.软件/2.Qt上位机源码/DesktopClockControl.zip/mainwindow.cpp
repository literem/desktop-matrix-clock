#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>

#include <QtSerialPort/QSerialPort>

int currentIndex=0;

QString buttonSelectStyle = "background-color:rgb(0, 170, 255);border: none;color: #FFF;font-size: 16px;";
QString buttonUnselectStyle  = "background-color:rgb(185, 185, 185);border: none;color: #FFF;font-size: 16px;";

SerialDialog *dialogSerial;
DisplayStaticDialog *dialogStatic;
DisplayScrollDialog *dialogScroll;
DisplayClockDialog *dialogClock;

//QSerialPort* serialPort = new QSerialPort;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    dialogSerial = new SerialDialog(this);
    dialogStatic = new DisplayStaticDialog(this);
    dialogScroll = new DisplayScrollDialog(this);
    dialogClock  = new DisplayClockDialog(this);

    //添加页面
    ui->stackedWidget->addWidget(dialogSerial);
    ui->stackedWidget->addWidget(dialogStatic);
    ui->stackedWidget->addWidget(dialogScroll);
    ui->stackedWidget->addWidget(dialogClock);

    //显示页面作为主页
    ui->stackedWidget->setCurrentWidget(dialogSerial);

    //连接信号槽
    connect(ui->serialButton, &QPushButton::clicked, this, &MainWindow::SwitchToSerialDialog);
    connect(ui->staticButton, &QPushButton::clicked, this, &MainWindow::SwitchToStaticDialog);
    connect(ui->scrollButton, &QPushButton::clicked, this, &MainWindow::SwitchToScrollDialog);
    connect(ui->clockButton, &QPushButton::clicked, this, &MainWindow::SwitchToClockDialog);

    connect(dialogStatic,&DisplayStaticDialog::sendSerialData,  dialogSerial,&SerialDialog::serialDataHandle);
    connect(dialogScroll,&DisplayScrollDialog::sendSerialData,  dialogSerial,&SerialDialog::serialDataHandle);
    connect(dialogClock,&DisplayClockDialog::sendSerialData,    dialogSerial,&SerialDialog::serialDataHandle);
}

MainWindow::~MainWindow()
{
    delete ui;
	delete dialogSerial;
	delete dialogStatic;
	delete dialogScroll;
	delete dialogClock;
	
}

void MainWindow::SwitchToSerialDialog()
{
    if(currentIndex == 0) return;
    ui->serialButton->setStyleSheet(buttonSelectStyle);
    ui->staticButton->setStyleSheet(buttonUnselectStyle);
    ui->scrollButton->setStyleSheet(buttonUnselectStyle);
    ui->clockButton->setStyleSheet(buttonUnselectStyle);
    ui->stackedWidget->setCurrentWidget(dialogSerial);
    currentIndex = 0;
}

void MainWindow::SwitchToStaticDialog()
{
    if(currentIndex == 1) return;
    ui->serialButton->setStyleSheet(buttonUnselectStyle);
    ui->staticButton->setStyleSheet(buttonSelectStyle);
    ui->scrollButton->setStyleSheet(buttonUnselectStyle);
    ui->clockButton->setStyleSheet(buttonUnselectStyle);
    ui->stackedWidget->setCurrentWidget(dialogStatic);
    currentIndex = 1;
}

void MainWindow::SwitchToScrollDialog()
{
    if(currentIndex == 2) return;
    ui->serialButton->setStyleSheet(buttonUnselectStyle);
    ui->staticButton->setStyleSheet(buttonUnselectStyle);
    ui->scrollButton->setStyleSheet(buttonSelectStyle);
    ui->clockButton->setStyleSheet(buttonUnselectStyle);
    ui->stackedWidget->setCurrentWidget(dialogScroll);
    currentIndex = 2;
}

void MainWindow::SwitchToClockDialog()
{
    if(currentIndex == 3) return;
    ui->serialButton->setStyleSheet(buttonUnselectStyle);
    ui->staticButton->setStyleSheet(buttonUnselectStyle);
    ui->scrollButton->setStyleSheet(buttonUnselectStyle);
    ui->clockButton->setStyleSheet(buttonSelectStyle);
    ui->stackedWidget->setCurrentWidget(dialogClock);
    currentIndex = 3;
}
