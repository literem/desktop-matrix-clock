#ifndef SERIALDIALOG_H
#define SERIALDIALOG_H

#include "send_data_array.h"
#include "send_data_thread.h"

#include <QDialog>
#include <QList>
#include <QSerialPort>


namespace Ui {
class SerialDialog;
}

class SerialDialog : public QDialog
{
    Q_OBJECT

public:
    explicit SerialDialog(QWidget *parent = nullptr);
    ~SerialDialog();

    void threadSendDataHandle(quint8* dat,quint16 len);
    void serialDataHandle(QList<SendDataArray*> *list);

private slots:
    void on_buttonOpenSerial_clicked();

    void on_buttonScanSerial_clicked();

private:
    Ui::SerialDialog *ui;
    bool isOpened = false;
    QSerialPort *serialPort = nullptr;
    SendDataThread *sendThread = nullptr;

private:
    void openSerial();
    void closeSerial();
    void readData();
    QString getSerialPort();
    QSerialPort::BaudRate getSerialBaudRate();
    void setSerialStatusButton(bool status);
};

#endif // SERIALDIALOG_H
