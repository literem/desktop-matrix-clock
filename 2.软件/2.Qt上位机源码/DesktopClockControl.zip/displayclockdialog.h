#ifndef DISPLAYCLOCKDIALOG_H
#define DISPLAYCLOCKDIALOG_H

#include <QDialog>
#include "send_data_array.h"
#include <QList>

namespace Ui {
class DisplayClockDialog;
}

class DisplayClockDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DisplayClockDialog(QWidget *parent = nullptr);
    ~DisplayClockDialog();

Q_SIGNALS:
    void sendSerialData(QList<SendDataArray*> *list);

private slots:
    void on_buttonHMdisplay_clicked();

    void on_buttonHMSdisplay_clicked();

    void on_buttonClockSetting_clicked();

    void on_buttonTimingSetting_clicked();

    void on_buttonCountdownSetting_clicked();

    void on_buttonAnimSetting_clicked();

    void on_buttonMSTiming_clicked();

    void on_buttonHMSTiming_clicked();

    void on_buttonMSCountDown_clicked();

    void on_buttonHMSCountDown_clicked();

private:
    Ui::DisplayClockDialog *ui;
    QList<SendDataArray*> list;
    quint8 displayMode;
    quint8 timingMode;
    quint8 countdownMode;
};

#endif // DISPLAYCLOCKDIALOG_H
