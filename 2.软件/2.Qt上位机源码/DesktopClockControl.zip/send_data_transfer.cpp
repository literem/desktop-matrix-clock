#include "send_data_transfer.h"
#include <QRandomGenerator>

#include "matrix_command.h"

SendDataArray* SendDataTransfer::createStartFrame(quint8 cmd,quint8 frameCount,quint8 frameID,quint16 frameLen)
{
    SendDataArray *sda = new SendDataArray(12);
    sda->array[0] = 0xff;
    sda->array[1] = 0xff;
    sda->array[2] = 0x0C;
    sda->array[3] = BIT3_DAT;
    sda->array[4] = cmd;
    sda->array[5] = cmd;
    sda->array[6] = frameID;
    sda->array[7] = frameLen >> 8;
    sda->array[8] = frameLen & 0xff;
    sda->array[9] = frameCount;
    sda->array[10] = 0xff;
    sda->array[11] = 0xff;
    return sda;
}

SendDataArray *SendDataTransfer::createOneFrame(quint8* dat,quint16 datLen,quint8 frameID,quint8 frameCount,quint8 frameIndex)
{
    quint16 frameLen = datLen + 8;
    SendDataArray *sda = new SendDataArray(frameLen);

    sda->array[0] = 0xff;               //起始位
    sda->array[frameLen-1] = 0xff;      //结束位
    sda->array[frameLen-2] = frameLen;  //帧总长度
    sda->array[frameLen-3] = frameID;   //帧ID
    sda->array[1] = FRAME_PART;         //数据帧标识位
    sda->array[2] = frameCount;         //总帧数
    sda->array[3] = frameIndex;         //帧序号
    sda->array[4] = datLen;             //帧的数据长度

    int start = 5;
    int end = frameLen - 4;
    for (int i=0; start <= end; ++start,i++) {
        sda->array[start] = dat[i];
    }
    return sda;
}


QList<SendDataArray *>* SendDataTransfer::createFrame(quint8* dat, quint16 len, quint8 cmd, quint16 payloadSize)
{
    QList<SendDataArray *> *list = new QList<SendDataArray *>();

    quint8 frameID = QRandomGenerator::global()->bounded(255);

    //根据每一帧的payloadSize算出一共要发送多少帧
    int frameCount = len / payloadSize;
    int remain = len % payloadSize;
    int totalCount = remain==0? frameCount:frameCount+1;
    int frameIndex = 0;

    list->append(createStartFrame(cmd,totalCount,frameID,len));
    for(;frameIndex < frameCount; frameIndex++)
    {
        list->append(createOneFrame(&dat[frameIndex*payloadSize],payloadSize,frameID,totalCount,frameIndex+1));
    }
    if(remain > 0)
    {
        list->append(createOneFrame(&dat[frameCount*payloadSize],remain,frameID,totalCount,frameIndex+1));
    }
    return list;
}

SendDataArray *SendDataTransfer::createCommand(quint8 cmd, quint32 dat)
{
    SendDataArray *sda = new SendDataArray(12);
    sda->array[0] = 0xff;
    sda->array[1] = 0xff;
    sda->array[2] = 0x0C;
    sda->array[3] = BIT3_CMD;
    sda->array[4] = cmd;
    sda->array[5] = cmd;
    sda->array[6] = dat >> 16;
    sda->array[7] = dat >> 8;
    sda->array[8] = dat & 0xff;
    sda->array[9] = 0;
    sda->array[10] = 0xff;
    sda->array[11] = 0xff;
    return sda;
}
