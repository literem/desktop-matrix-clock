#include "send_data_array.h"

SendDataArray::SendDataArray(int size) : arraySize(size),array(new quint8[size])
{
}

SendDataArray::~SendDataArray()
{
    delete[] array;
}
