#ifndef SEND_DATA_THREAD_H
#define SEND_DATA_THREAD_H

#include "send_data_array.h"
#include "matrix_command.h"

#include <QThread>
#include <QList>
#include <QMutex>
#include <QWaitCondition>

#include <QDebug>

class SendDataThread : public QThread
{
    Q_OBJECT

public:
    ~SendDataThread()
    {
        isLoop = false;
    }

Q_SIGNALS:
    void sendData(quint8* dat,quint16 len);

public:
    void setList(QList<SendDataArray*> *list)
    {
        this->list = list;
        quint8* array0 = list->at(0)->array;
        if(array0[3] != BIT3_DAT) return;
        frameID = array0[6];
        frameCount = array0[9];
    }

    void frameResponse(quint8 frame_count,quint8 frame_index,quint8 frame_id)
    {
        if(frame_id == frameID && frame_count == frameCount)
        {
            //qDebug() << "isResponse = true,frame_index:" << frame_index;
            frameIndex = frame_index;
            isResponse = true;
        }
    }

    void sendFinish(quint8 frame_id)
    {
        if(frame_id == frameID)
        {
            isResponse = true;
            listMaxCount = 0;
        }
    }

    void wakeUp()
    {
        QMutexLocker locker(&mutex);
        condition.wakeOne();
    }

    void wakeUpAndExit()
    {
        isLoop = false;
        QMutexLocker locker(&mutex);
        condition.wakeOne();
    }

private:
    QWaitCondition condition;
    QMutex mutex;
    QList<SendDataArray*> *list = nullptr;
    bool isLoop = true;

    quint8 frameCount;
    quint8 frameIndex;
    quint8 frameID;

    int waitTime;
    int listMaxCount;
    bool isResponse = false;

    bool waitResponse()
    {
        isResponse = false;
        waitTime = 0;
        while(true)
        {
            waitTime++;
            if(waitTime > 500) return true;
            if(isResponse) return false;
            msleep(2);
        }
    }

public:
    void run() override
    {
        QMutexLocker locker(&mutex);//加锁
        while(isLoop)
        {
            if(list != nullptr && list->size() != 0)
            {
                //qDebug() << "thread send start!";
                listMaxCount = list->size() * 2;
                emit sendData(list->at(0)->array,list->at(0)->arraySize);
                while(listMaxCount-- > 0)
                {
                    if(waitResponse()) break;
                    if(frameIndex != 0 && frameIndex < list->size())
                    {
                        //qDebug() << "send data frame index:" << frameIndex;
                        emit sendData(list->at(frameIndex)->array,list->at(frameIndex)->arraySize);
                    }
                }
                qDeleteAll(*list);
                list->clear();
                delete list;
                list = nullptr;
            }
            msleep(100);
            //qDebug() << "thread send finish! sleeping...";
            condition.wait(&mutex);//线程挂起，直到调用wakeUp函数后，继续往下执行
        }
        //qDebug() << "thread exit!";
    }
};

#endif // SEND_DATA_THREAD_H

