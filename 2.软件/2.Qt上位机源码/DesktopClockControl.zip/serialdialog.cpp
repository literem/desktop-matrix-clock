#include "serialdialog.h"
#include "ui_serialdialog.h"

#include <QSerialPortInfo>
#include <QSerialPort>
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>

#include "matrix_command.h"

SerialDialog::SerialDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::SerialDialog)
{
    ui->setupUi(this);
    ui->comboBoxBaudRate->setCurrentText("9600");

    QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();
    if(ports.count() != 0)
    {
        ui->comboBoxSerial->clear();
        foreach (QSerialPortInfo info, ports)
        {
            ui->comboBoxSerial->addItem(info.portName() + " " + info.description());
        }
    }

    sendThread = new SendDataThread();
    sendThread->start();
    connect(sendThread,&SendDataThread::sendData,this,&SerialDialog::threadSendDataHandle);
}

SerialDialog::~SerialDialog()
{
    if(sendThread != nullptr)
    {
        sendThread->wakeUpAndExit();
        QThread::msleep(100);
        delete sendThread;
    }
    delete ui;
    delete serialPort;
}

void SerialDialog::threadSendDataHandle(quint8* dat, quint16 len)
{
    if(serialPort == nullptr) return;
    if(!serialPort->isOpen()) return;
    serialPort->write((char*)dat,len);
}

void SerialDialog::serialDataHandle(QList<SendDataArray*> *list)
{
    if(serialPort == nullptr)
    {
        QMessageBox::warning(this,"提示","数据发送失败，串口对象为空！");
        return;
    }

    if(!serialPort->isOpen())
    {
        QMessageBox::warning(this,"提示","数据发送失败，串口未打开！");
        return;
    }

    if(list->size() == 0)
    {
        QMessageBox::warning(this,"提示","没有数据可以发送！");
        return;
    }
    if(list->size() == 1)
    {
        int result = serialPort->write((char*)list->at(0)->array,list->at(0)->arraySize);
        if(result == -1)
        {
            QMessageBox::warning(this,"提示","数据发送失败，请检查串口是否连接正常！");
        }
    }
    else
    {
        sendThread->setList(list);
        sendThread->wakeUp();
    }
}

void SerialDialog::on_buttonOpenSerial_clicked()
{
    if(serialPort == nullptr)
    {
        serialPort = new QSerialPort();
        serialPort->setDataBits(QSerialPort::Data8);// 设置数据位数
        serialPort->setStopBits(QSerialPort::OneStop);// 设置停止位数
        serialPort->setParity(QSerialPort::NoParity);// 设置奇偶校验位
        serialPort->setFlowControl(QSerialPort::NoFlowControl);// 设置流控制
    }

    if(serialPort->isOpen() != isOpened)
    {
        closeSerial();
        QMessageBox::warning(this,"提示","串口发生错误，请重新打开");
        return;
    }

    if(serialPort->isOpen())
    {
        closeSerial();
    }
    else
    {
        openSerial();
    }
}


void SerialDialog::on_buttonScanSerial_clicked()
{
    QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();
    if(ports.count() == 0)
    {
        ui->comboBoxSerial->clear();
        return;
    }
    ui->comboBoxSerial->clear();
    foreach (QSerialPortInfo info, ports)
    {
        ui->comboBoxSerial->addItem(info.portName() + " " + info.description());
    }
}

void SerialDialog::openSerial()
{
    QString com = getSerialPort();
    QSerialPort::BaudRate baudRate = getSerialBaudRate();

    if(com.size() == 0)
    {
        QMessageBox::warning(this,"提示","请选择一个串口号");
        return;
    }

    if(baudRate == QSerialPort::UnknownBaud)
    {
        QMessageBox::warning(this,"提示","请选择一个正确的波特率");
        return;
    }

    serialPort->setPortName(com);// 设置串口名称
    serialPort->setBaudRate(baudRate);// 设置波特率

    if(serialPort->open(QIODevice::ReadWrite))
    {
        isOpened = true;
        setSerialStatusButton(serialPort->isOpen());
        connect(serialPort, &QSerialPort::readyRead, this, &SerialDialog::readData);
        if(sendThread == nullptr)
        {
            sendThread = new SendDataThread();
            connect(sendThread,&SendDataThread::sendData,this,&SerialDialog::threadSendDataHandle);
            sendThread->start();
        }
    }
    else
    {
        QString errMsg;
        QSerialPort::SerialPortError e = serialPort->error();
        switch(e)
        {
            case QSerialPort::TimeoutError:errMsg = "串口打开超时！";break;
            case QSerialPort::NoError:break;
            case QSerialPort::DeviceNotFoundError:errMsg = "串口打开失败，串口设备未找到！";break;
            case QSerialPort::PermissionError:errMsg = "串口打开失败，串口被占用！";break;
            case QSerialPort::OpenError:errMsg = "串口打开错误！";break;
            case QSerialPort::ParityError:
            case QSerialPort::FramingError:
            case QSerialPort::BreakConditionError:
            case QSerialPort::WriteError:
            case QSerialPort::ReadError:errMsg = "串口打开失败！";break;
            case QSerialPort::ResourceError:errMsg = "串口打开失败，资源错误！";break;
            case QSerialPort::UnsupportedOperationError:errMsg = "串口打开失败，不支持的操作！";break;
            case QSerialPort::UnknownError:errMsg = "串口打开失败，未知错误！";break;
            case QSerialPort::NotOpenError:break;
        }
        QMessageBox::warning(this,"提示",errMsg);
    }
}

void SerialDialog::closeSerial()
{
    if(serialPort->isOpen())
    {
        serialPort->clear();
        serialPort->close();
        if(sendThread != nullptr)
        {
            sendThread->wakeUpAndExit();
            QThread::msleep(100);
            delete sendThread;
            sendThread = nullptr;
        }
    }
    setSerialStatusButton(false);
    isOpened = false;
}

void SerialDialog::readData()
{
    QByteArray buf = serialPort->readAll();
    int len = buf.size();
    quint8* dat = (quint8*) buf.data();
    if(len == 9)
    {
        if( dat[0] == 0xff && dat[1] == 0xff &&
            dat[7] == 0xff && dat[8] == 0xff &&
            dat[2] == len)
        {
            if(dat[3] == BIT3_REQUEST)
            {
                sendThread->frameResponse(dat[4],dat[5],dat[6]);
            }
            else if(dat[3] == BIT3_FINISH)
            {
                sendThread->sendFinish(dat[6]);
            }
            return;
        }
    }

    if(!buf.isEmpty())
    {
        //QDateTime currentTime = QDateTime::currentDateTime();
        //QString str = tr(buf);
        //qDebug() << currentTime.toString("yyyy-MM-dd HH:mm:ss ->>> ") << str;
        buf.clear();
    }
}

QString SerialDialog::getSerialPort()
{
    QString com = ui->comboBoxSerial->currentText();
    return com.left(4);
}

QSerialPort::BaudRate SerialDialog::getSerialBaudRate()
{
    switch(ui->comboBoxBaudRate->currentIndex())
    {
        case 0:  return QSerialPort::Baud1200;
        case 1:  return QSerialPort::Baud2400;
        case 2:  return QSerialPort::Baud4800;
        case 3:  return QSerialPort::Baud9600;
        case 4:  return QSerialPort::Baud19200;
        case 5:  return QSerialPort::Baud38400;
        case 6:  return QSerialPort::Baud57600;
        case 7:  return QSerialPort::Baud115200;
        default: return QSerialPort::UnknownBaud;
    }
}

void SerialDialog::setSerialStatusButton(bool status)
{
    if(status)
    {
        //设置打开后的状态
        ui->buttonOpenSerial->setText("关闭串口");
        ui->buttonOpenSerial->setStyleSheet("background:rgb(255, 0, 0);border-radius:10px;color:white;");
    }
    else
    {
        //设置关闭后的状态
        ui->buttonOpenSerial->setText("打开串口");
        ui->buttonOpenSerial->setStyleSheet("background:rgb(0, 170, 255);border-radius:10px;color:white;");
    }
}

