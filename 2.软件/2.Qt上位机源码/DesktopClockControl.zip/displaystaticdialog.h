#ifndef DISPLAYSTATICDIALOG_H
#define DISPLAYSTATICDIALOG_H

#include "gbk_utils.h"
#include "send_data_array.h"

#include <QDialog>
#include <QPixmap>
#include <QImage>
#include <QTimerEvent>
#include <QList>

namespace Ui {
class DisplayStaticDialog;
}

class DisplayStaticDialog : public QDialog
{
    Q_OBJECT

public:
    explicit DisplayStaticDialog(QWidget *parent = nullptr);
    ~DisplayStaticDialog();

private slots:
    void on_openImageButton_clicked();

    void on_removeImageBtn_clicked();

    void on_charTransferBtn_clicked();

    void on_imgTransferBtn_clicked();

    void on_horizontalSlider_valueChanged(int value);

    void on_shiftLeftButton_clicked();

    void on_shiftRightButton_clicked();

    void on_buttonSend_clicked();

Q_SIGNALS:
    void sendSerialData(QList<SendDataArray*> *list);

private:
    Ui::DisplayStaticDialog *ui;

    void showPreviewImage(QPixmap &pixmap);
    void hidePreviewImage();
    void transferImage(QString &path);
    QImage gray(QImage image);
    void twoSide(QImage grayimage,int value);
    GBKUtils *gbkUtils = nullptr;
    int m_Id1,m_Id2;
};

#endif // DISPLAYSTATICDIALOG_H
