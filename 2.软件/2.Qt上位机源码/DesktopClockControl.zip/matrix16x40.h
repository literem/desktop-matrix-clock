#ifndef MATRIX16X40_H
#define MATRIX16X40_H

#include <QWidget>
#include <QPainter>
#include <QPen>
#include <QMouseEvent>
#include <QDebug>
#include <QVector>

#define START_X     5
#define START_Y     5
#define PADDING_X   15
#define PADDING_Y   15
#define RADIUS      10

namespace Ui {
class Matrix16x40;
}

class Matrix16x40 : public QWidget
{
    Q_OBJECT

public:
    explicit Matrix16x40(QWidget *parent = nullptr);
    ~Matrix16x40();
    quint8 *getBuff();
    void createHex(quint8 **result);
    void setBuff(int x,int y,quint8 v);
    void cleanBuff();
    void refresh();
    void shiftLeft();
    void shiftRight();

protected:
    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *e);//--鼠标按下事件
    void mouseMoveEvent(QMouseEvent *e);//--鼠标移动事件
    void mouseReleaseEvent(QMouseEvent *e);//--鼠标释放（松开）事件

private:
    Ui::Matrix16x40 *ui;

    quint8 binToHex(quint8 y,quint8 x);
};

#endif // MATRIX16X40_H
