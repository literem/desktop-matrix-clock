#include "displaystaticdialog.h"
#include "ui_displaystaticdialog.h"

#include <QFileDialog>
#include <QMessageBox>
#include <QBitmap>
#include <QElapsedTimer>

#include "gbk_utils.h"
#include "send_data_transfer.h"
#include "matrix_command.h"

QString imgPath;
QString twoSideText = "二值化阈值：";
int twoSideValue = 128;

DisplayStaticDialog::DisplayStaticDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::DisplayStaticDialog)
{
    ui->setupUi(this);

    ui->imageLabel->setVisible(false);
    ui->removeImageBtn->setVisible(false);
}

DisplayStaticDialog::~DisplayStaticDialog()
{
    delete ui;
    delete gbkUtils;
}

void DisplayStaticDialog::on_openImageButton_clicked()
{
    QString filename;
    filename = QFileDialog::getOpenFileName(this,tr("选择图像"),"",tr("Images (*.png *.bmp *.jpg)"));
    if(filename.isEmpty())
    {
        return;
    }

    QImage* img = new QImage,* scaledimg = new QImage;//分别保存原图和缩放之后的图片
    if(!(img->load(filename))) //加载图像
    {
        delete img;
        delete scaledimg;
        QMessageBox::warning(this,"打开图像失败","打开图像失败!");
        return;
    }
    int o_width=img->width();
    int o_height=img->height();

    if(o_width > 70 && o_height > 70)
    {
        float Mul;
        if(o_width >= o_height)
            Mul = o_width / 70.0;
        else
            Mul = o_height / 70.0;
        *scaledimg=img->scaled(o_width / Mul,o_height / Mul,Qt::KeepAspectRatio);
        ui->imageLabel->setPixmap(QPixmap::fromImage(*scaledimg));
    }
    else
    {
        ui->imageLabel->setPixmap(QPixmap::fromImage(*img));
    }
    ui->imageLabel->setVisible(true);
    ui->removeImageBtn->setVisible(true);
    imgPath = filename;
    delete scaledimg;
    delete img;
}

void DisplayStaticDialog::on_removeImageBtn_clicked()
{
    ui->imageLabel->setVisible(false);
    ui->removeImageBtn->setVisible(false);
    imgPath.clear();
}

void DisplayStaticDialog::on_charTransferBtn_clicked()
{
    QString strdata = ui->charTransferEdit->text();
    int len = strdata.size();
    if(len == 0)
    {
        QMessageBox::warning(this,"提示","请输入内容");
        return;
    }
    if(gbkUtils == nullptr)
    {
        gbkUtils = new GBKUtils();
    }
    quint8 (*matrix_buff)[40] = (quint8 (*)[40])ui->matrix->getBuff();
    bool isReverse = ui->reverseCheckBox->isChecked();
    quint8 start_pos = ui->centerCheckBox->isChecked() ? (40-(len*16))/2 : 0;
    ui->matrix->cleanBuff();
    for(int i=0;i<len;i++,start_pos+=16)
    {
        QString str = QString(strdata.at(i));
        gbkUtils->createMatrixFont(str,matrix_buff,start_pos,isReverse);
    }
    ui->matrix->refresh();
}

void DisplayStaticDialog::transferImage(QString &path)
{
    if(path.isEmpty())
    {
        QMessageBox::warning(this,"提示","图片转换失败，图片路径为空");
        return;
    }
    QImage* img = new QImage;
    if(!(img->load(path))) //加载图像
    {
        QMessageBox::information(this,tr("提示"),tr("打开图像失败!"));
        delete img;
        return;
    }
    int mul = img->height() / 16;
    QImage grayimage = gray(img->scaled(img->width()/mul, img->height()/mul, Qt::KeepAspectRatio));
    twoSide(grayimage,twoSideValue);
}


void DisplayStaticDialog::on_imgTransferBtn_clicked()
{
    if(ui->imageLabel->isHidden())
    {
        QMessageBox::warning(this,"提示","请先选择图片后再转换");
        return;
    }

    if(!imgPath.isEmpty())
    {
        transferImage(imgPath);
    }
}


//二值化
void DisplayStaticDialog::twoSide(QImage grayimage,int value)
{
    QColor oldColor;
    int ts;
    quint8 isReverse = ui->reverseCheckBox->isChecked() ? 1 : 0;
    int offset = ui->centerCheckBox->isChecked() ? (40-grayimage.width())/2 : 0;

    int y,x,x_start;

    ui->matrix->cleanBuff();
    for(y = 0; y < grayimage.height(); y++)
    {
        for(x = 0,x_start = offset; x < grayimage.width(); x++,x_start++)
        {
            oldColor = QColor(grayimage.pixel(x,y));
            ts = oldColor.red();
            if(ts<value){
                ui->matrix->setBuff(y,x_start,isReverse);
            }else{
                ui->matrix->setBuff(y,x_start,!isReverse);
            }
        }
    }
    ui->matrix->refresh();
}


//灰度化
QImage DisplayStaticDialog::gray(QImage image)
{
    QImage newImage =image.convertToFormat(QImage::Format_ARGB32);
    QColor oldColor;
    int average;
    for(int y = 0; y < newImage.height(); y++)
    {
        for(int x = 0; x < newImage.width(); x++)
        {
            oldColor = QColor(image.pixel(x,y));
            average = (oldColor.red() + oldColor.green() + oldColor.blue()) / 3;
            newImage.setPixel(x, y, qRgb(average, average, average));
        }
    }
    return newImage;
}


void DisplayStaticDialog::on_horizontalSlider_valueChanged(int value)
{
    ui->twoSideLabel->setText(twoSideText + QString::number(value));
    twoSideValue = value;
}


void DisplayStaticDialog::on_shiftLeftButton_clicked()
{
    ui->matrix->shiftLeft();
}


void DisplayStaticDialog::on_shiftRightButton_clicked()
{
    ui->matrix->shiftRight();
}

void DisplayStaticDialog::on_buttonSend_clicked()
{
    quint8 temp[80];
    quint8 *t = temp;
    ui->matrix->createHex(&t);
    QList<SendDataArray*> *list = SendDataTransfer::createFrame(temp,80,CMD_CUSTOM,80);
    emit sendSerialData(list);
}
