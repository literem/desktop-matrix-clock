#ifndef SENDDATAARRAY_H
#define SENDDATAARRAY_H

#include <QtGlobal>

class SendDataArray
{
public:
    SendDataArray(int size);
    ~SendDataArray();
public:
    int arraySize;
    quint8* array;
};

#endif // SENDDATAARRAY_H
