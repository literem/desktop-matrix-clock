#ifndef __MATRIX_CONFIG_H
#define __MATRIX_CONFIG_H

#include "Arduino.h"

//显示屏的显示模式
#define MODE_CLOCK        1  //时钟显示
#define MODE_CUSTOM       2  //自定义显示
#define MODE_SCROLL       3  //滚动显示
#define MODE_TIMING_2     4  //计时显示
#define MODE_TIMING_3     5  //计时显示
#define MODE_COUNTDOWN_2  6  //倒计时显示
#define MODE_COUNTDOWN_3  7  //倒计时显示

//显示屏的设置模式
#define MODE_ANIM       6  //设置动画
#define MODE_SPEED      7  //设置滚动速度

#define CLOCK_MMSS     0
#define CLOCK_HHMM     1
#define CLOCK_HHMMSS   2

#define CLOCK_ANIM_NONE 0
#define CLOCK_ANIM_UP   1
#define CLOCK_ANIM_DOWN 2

#endif
