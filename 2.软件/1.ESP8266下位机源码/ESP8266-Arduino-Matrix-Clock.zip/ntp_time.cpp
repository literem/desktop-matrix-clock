#include <NTPClient.h>
#include <WiFiUdp.h>
#include <ESP8266WiFi.h>
#include "ConnectWiFi.h"

WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "ntp1.aliyun.com", 60*60*8, 60000);

/*
  函数说明：NTP网络时钟初始化
*/
void ntp_time_init()
{
  uint8_t n = 10;
  if(!WiFi.isConnected())
  {
    wifi_init();
  }
  timeClient.begin();
  delay(500);
  while(--n != 0)
  {
      if(timeClient.update()) return;
      delay(200);
  }
}

/*
  函数说明：获取NTP时间
*/
u32 get_ntp_time()
{
  u32 t=0;
  u8 temp;
  timeClient.update();
  
  temp = (u8) timeClient.getSeconds();
  t = temp;

  temp = (u8) timeClient.getMinutes();
  t += temp << 8;
  
  temp = (u8) timeClient.getHours();
  t += temp << 16;
  return t;
}
