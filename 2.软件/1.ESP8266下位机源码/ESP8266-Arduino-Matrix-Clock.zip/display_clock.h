#ifndef __DISPLAY_CLOCK_H
#define __DISPLAY_CLOCK_H

#include "matrix_config.h"
#include "scanning.h"

extern u8 clockSecond;
extern u8 clockMinute;
extern u8 clockHour;
extern u8 originalSecond;
extern u8 originalMinute;
extern u8 originalHour;

extern u8 timingPause;
extern u8 dot_toggle;

void monitor_anim(void);
void monitor_time(void);
void monitor_timing(void);
void monitor_countdown(void);
void timing_init(void);
void timing_key_handle(u8 m);

void change_clock_anim(u8 clock_mode, u8 anim_mode);
void set_clock_mode(u8 clock_mode,u8 anim_mode);
void set_clock_time(u8 hour,u8 minute,u8 second);

#endif
