#ifndef __DISPLAY_SCROLL_H
#define __DISPLAY_SCROLL_H

#include <Arduino.h>

typedef struct {
    union {
        uint8_t num;
        struct {
            uint8_t bit0:1;
            uint8_t :7;
        };
    }ch1;
    union {
        uint8_t num;
        struct {
            uint8_t bit0:1;
            uint8_t :6;
            uint8_t bit7:1;
        };
    }ch2;
    union {
        uint8_t num;
        struct {
            uint8_t bit0:1;
            uint8_t :6;
            uint8_t bit7:1;
        };
    }ch3;
    union {
        uint8_t num;
        struct {
            uint8_t bit0:1;
            uint8_t :6;
            uint8_t bit7:1;
        };
    }ch4;
    union {
        uint8_t num;
        struct {
            uint8_t bit0:1;
            uint8_t :6;
            uint8_t bit7:1;
        };
    }ch5;
}__attribute__ ((packed)) matrix_line_t;//关闭内存对齐

extern u8 scroll_buf[20][32];

void monitor_scroll(void);
void scroll_init(u8 count);
#endif
