#ifndef __PLATFORM_STM32_H
#define __PLATFORM_STM32_H
#include "Arduino.h"

#define delay_us(t)   delayMicroseconds(t)
#define delay_ms(t)   delay(t)
#define NOP()

//引脚配置
#define A1_138  D1
#define A2_138  D2
#define A3_138  D3
#define A4_138  D4
#define OE_138  D0
#define SER     D7
#define CLK     D5
#define RCK     D8

//74hc138
#define A1_HIGH()   digitalWrite(A1_138,HIGH)
#define A1_LOW()    digitalWrite(A1_138,LOW)
#define A2_HIGH()   digitalWrite(A2_138,HIGH)
#define A2_LOW()    digitalWrite(A2_138,LOW)
#define A3_HIGH()   digitalWrite(A3_138,HIGH)
#define A3_LOW()    digitalWrite(A3_138,LOW)
#define A4_HIGH()   digitalWrite(A4_138,HIGH)
#define A4_LOW()    digitalWrite(A4_138,LOW)
#define HC138_Enable()    digitalWrite(OE_138,LOW)
#define HC138_Disable()   digitalWrite(OE_138,HIGH)

//74hc595
#define SER_HIGH()  digitalWrite(SER,HIGH)
#define SER_LOW()   digitalWrite(SER,LOW)
#define CLK_HIGH()  digitalWrite(CLK,HIGH)
#define CLK_LOW()   digitalWrite(CLK,LOW)
#define RCK_HIGH()  digitalWrite(RCK,HIGH)
#define RCK_LOW()   digitalWrite(RCK,LOW)

/*
  函数说明：初始化74HC595和74HC138所需的引脚
*/
void scanning_init()
{
  pinMode(A1_138,OUTPUT);
  pinMode(A2_138,OUTPUT);
  pinMode(A3_138,OUTPUT);
  pinMode(A4_138,OUTPUT);
  pinMode(OE_138,OUTPUT);
  pinMode(SER,OUTPUT);
  pinMode(CLK,OUTPUT);
  pinMode(RCK,OUTPUT);
}

#endif
