#ifndef __RECEIVE_H
#define __RECEIVE_H

#include <Arduino.h>

#define getFrameLen(d) ((d[7]<<8) + d[8])

//命令/数据标志位
#define BIT3_DAT        0xA1
#define BIT3_CMD        0xA2
#define BIT3_REQUEST    0xA3
#define BIT3_FINISH     0xA4
#define FRAME_PART      0xA5 //数据帧标志位

#define CMD_CUSTOM      0xC0 //自由显示
#define CMD_SCROLL      0xC1 //滚动显示
#define CMD_CLOCK       0xC2 //时钟显示
#define CMD_TIMING_2    0xC3 //计时显示（分秒）
#define CMD_TIMING_3    0xC4 //计时显示（时分秒）
#define CMD_COUNTDOWN_2 0xC5 //倒计时显示（分秒）
#define CMD_COUNTDOWN_3 0xC6 //倒计时显示（时分秒）
#define CMD_SPEED       0xC7 //设置速度
#define CMD_ANIM        0xC8 //设置动画

extern u8 frameID;
extern u8 frameCount;
extern u8 scrollArrayIndex;
extern u8 value_1;
extern u8 value_2;
extern u8 value_3;

s8 receiveHandle(u8 *dat,u8 len);
s8 handleCommand(u8 *dat,u8 len);
s8 handleFrame(u8 *dat,u8 len,u8 order,u8 handleMode);
s8 isFrameFinish(u8 *dat,u8 len);
#endif
