#include "display.h"
#include "ConnectWiFi.h"
#include "InfoPrint.h"
#include "ntp_time.h"

extern "C" {
#include "display_clock.h"
#include "receive.h"
#include "display_scroll.h"
}

#include <Ticker.h>

Ticker timer1;
Ticker timer2;

void (*displaying)(void);
void (*timer1_function)(void);

u8 ntpUpdateDelay = 0;
u8 currentClockAnim;
u8 currentClockMode;
u8 displayMode = 0;
u16 scrollSpeed = 500;

unsigned long lastTime = 0;

/*
  函数说明：更新NTP网络时间
*/
void updateNtpTime() {
    u32 t = get_ntp_time();
    set_clock_time((t >> 16), (t >> 8), t);
}

/*
  函数说明：定时器计时调用的函数
*/
void t1_clock_counting() {
    monitor_time();
    ntpUpdateDelay++;
    if (ntpUpdateDelay == 30) {
        ntpUpdateDelay = 0;
        updateNtpTime();
    }
}

void timer1_cb() {
    timer1_function();
}

void timer2_cb() {
    monitor_anim();
}

/*
  函数说明：设置计时/倒计时
  参数说明：clock_mode：显示模式，有分秒和时分秒显示
          timing：“计时/倒计时”选择
*/
void set_timing(u8 timing,u8 clock_mode)
{
    timer1.detach();
    timer2.detach();
    currentClockMode = clock_mode;
    originalSecond = clockSecond;
    originalMinute = clockMinute;
    originalHour = clockHour;
    set_clock_mode(clock_mode, currentClockAnim);
    set_clock_time(clockHour,clockMinute,clockSecond);
    timing_init();
    if(timing == 1)
      timer1_function = monitor_timing;//计时
    else
      timer1_function = monitor_countdown;//倒计时
    timer1.attach_ms(1000, timer1_cb);
    timer2.attach_ms(25, timer2_cb);
}

/*
  函数说明：设置点阵屏幕的显示模式
*/
void set_display_mode(u8 m)
{
    switch (m)
    {
        case MODE_CLOCK:
            if(currentClockMode != CLOCK_HHMM && currentClockMode != CLOCK_HHMMSS) 
                currentClockMode = CLOCK_HHMM;
            set_clock_mode(currentClockMode, currentClockAnim);
            updateNtpTime();
            dot_toggle = 1;
            timer1_function = t1_clock_counting;
            timer1.attach_ms(1000, timer1_cb);
            timer2.attach_ms(25, timer2_cb);
            break;

        case MODE_CUSTOM:
            timer1.detach();
            timer2.detach();
            break;

        case MODE_SCROLL:
            timer2.detach();
            clean_matrix_buf();
            scroll_init(scrollArrayIndex);
            timer1_function = monitor_scroll;
            timer1.attach_ms(scrollSpeed, timer1_cb);
            break;
            
        case MODE_TIMING_2:
            set_timing(1,CLOCK_MMSS);
            break;
            
        case MODE_TIMING_3:
            set_timing(1,CLOCK_HHMMSS);
            break;

        case MODE_COUNTDOWN_2:
            set_timing(0,CLOCK_MMSS);
            break;

        case MODE_COUNTDOWN_3:
            set_timing(0,CLOCK_HHMMSS);
            break;
        
        default:return;
    }
    displayMode = m;
}

/*
  函数说明：设置显示参数，动画和滚动速度
*/
void set_display_args(u8 m,u16 value)
{
    if(m == MODE_ANIM)
    {
        if(displayMode != MODE_CUSTOM && displayMode != MODE_SCROLL)
        {
            currentClockAnim = value;
            change_clock_anim(currentClockMode, currentClockAnim);
        }
    }
    else if(m == MODE_SPEED)
    {
        if(displayMode == MODE_SCROLL)
        {
            scrollSpeed = value;
            timer1.attach_ms(scrollSpeed, timer1_cb);
        }
    }
}

/*********** 按键相关 *************/
/*
  函数说明：按键中断函数
*/
void ICACHE_RAM_ATTR key_isr() 
{
    if((millis() - lastTime) < 200) return;
    lastTime = millis(); // 更新上一次时间戳
    
    if(displayMode == MODE_CLOCK)
    {
        timer1.detach();
        timer2.detach();
        currentClockMode = (currentClockMode==CLOCK_HHMM) ? CLOCK_HHMMSS : CLOCK_HHMM;
        set_display_mode(MODE_CLOCK);
    }
    else if(displayMode == MODE_TIMING_2 || displayMode == MODE_TIMING_3 || 
            displayMode == MODE_COUNTDOWN_2 || displayMode == MODE_COUNTDOWN_3)
    {
        timing_key_handle(displayMode);
    }
}

/*
  函数说明：按键初始化
*/
void key_init() {
    //启动时检测按钮，如果长按1s，则进入配网模式
    pinMode(D6, INPUT_PULLUP);
    if (digitalRead(D6) == LOW) {
        delay(1000);
        if (digitalRead(D6) == LOW) start_network_adapter();
    }
    attachInterrupt(D6, key_isr, RISING);
}

/*
  函数说明：显示初始化
*/
void display_init() {
    scanning_init();
    currentClockAnim = CLOCK_ANIM_NONE;
    currentClockMode = CLOCK_HHMMSS;
    displaying = scan_one_frame;
    clean_matrix_buf();
}
