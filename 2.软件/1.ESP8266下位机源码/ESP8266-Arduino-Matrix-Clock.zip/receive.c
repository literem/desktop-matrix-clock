#include <string.h>
#include "receive.h"
#include "scanning.h"
#include "display_scroll.h"

u8 frameID;     //帧ID
u8 frameCount;  //一共要接收多少帧
u8 frameIndex;  //当前接收的帧序号
u16 frameLen;   //帧长度
u8 scrollArrayIndex;//接收滚动显示的数据在数组中的索引

//接收命令的保存值
u8 value_1;
u8 value_2;
u8 value_3;

/*
  函数说明：处理接收的数据，接收数据的总入口
*/
s8 receiveHandle(u8 *dat, u8 len) {
    if (dat[0] != 0xff || dat[1] != 0xff) return -1;
    if (dat[len - 1] != 0xff || dat[len - 2] != 0xff) return -1;
    if (dat[2] != len) return -1;

    if (dat[3] == BIT3_DAT)
    {
        frameID = dat[6];
        frameCount = dat[9];
        frameLen = getFrameLen(dat);
        if(dat[4] == CMD_CUSTOM)
        {
            return CMD_CUSTOM;
        }
        else if(dat[4] == CMD_SCROLL)
        {
            scrollArrayIndex = 0;
            return CMD_SCROLL;
        }
    }
    else if (dat[3] == BIT3_CMD)
    {
        return handleCommand(dat, len);
    }
    return -1;
}

/*
  函数说明：拷贝接收的帧数据到数组中
*/
s8 handleFrameData(u8 *dat, u8 len, u8 handleMode) {
    if (handleMode == CMD_CUSTOM) {
        if (len != 80) return -1;
        memcpy((u8 *) matrix_buf, dat, len);
    } else if (handleMode == CMD_SCROLL) {
        if(len % 32 != 0) return -1;
        memcpy(&scroll_buf[scrollArrayIndex][0], dat, len);
        scrollArrayIndex += (len/32);
    }
    return 0;
}

/*
  函数说明：判断一帧数据是否接收完毕
*/
s8 isFrameFinish(u8 *dat, u8 len) {
    if (len < 10) return -1;
    if (dat[len - 1] != 0xff) return -1;
    if (dat[0] == 0xff && dat[len - 3] == frameID && dat[len - 2] == len)
        return 0;
    return -1;
}

/*
  函数说明：处理帧数据
*/
s8 handleFrame(u8 *dat, u8 len, u8 order, u8 handleMode) {
    if (dat[0] != 0xff || dat[len - 1] != 0xff) return -1;//判断起始位和结束位
    if (dat[len - 2] != len) return -1;//判断帧总长
    if (dat[1] != FRAME_PART) return -1;//判断帧标志位
    if (dat[len - 3] != frameID) return -1;//判断帧ID
    if (dat[2] != frameCount || dat[3] != order) return -1;//判断总帧数和帧序号
    frameIndex = order;
    return handleFrameData(&dat[5], dat[4], handleMode);
}

s8 handleCommand(u8 *dat, u8 len) {
    u8 cmd = dat[4] & dat[5];
    value_1 = dat[6];
    value_2 = dat[7];
    value_3 = dat[8];
    return cmd;
}
