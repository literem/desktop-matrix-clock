#ifndef __STATE_INFO_H
#define __STATE_INFO_H

#include <Arduino.h>

extern class StateInfoPrint INFO;

class StateInfoPrint
{
  public:
    void init(void);
    void print(char* info);
    void print(char ch);
    void println(char* info);
    void requestFrame(u8 frame_count,u8 frame_index,u8 frame_id);
    void finishFrame(u8 frame_id);
};

#endif
