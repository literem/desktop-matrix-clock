#include "display_clock.h"
#include <string.h>

//时间的结构体
struct matrix_time_t {
    u8 hour_sd; //single digit 个位
    u8 hour_td; //ten digit    十位
    u8 minute_sd;
    u8 minute_td;
    u8 second_sd;
    u8 second_td;
};
struct matrix_time_t matrix_time = {0};

void (*anim_update_function)(void);//动画更新的指针函数
void (*anim_dot_update_function)(void);
u8 move_pos = 0;//动画更新进度
u8 is_can_move = 0;//是否可以更新动画
u8 dot_flag = 0;//点显示的标志
u8 dot_count = 0;//点显示的时长
u8 dot_toggle = 1;//是否开启闪烁时间点
u8 anim_update_pos;//动画更新起始位置
u8 clockMode;//当前显示模式
u8 time_update_flag = 0;//时间更新的标志
u8 timingPause = 0;

u8 clockSecond;
u8 clockMinute;
u8 clockHour;
u8 originalSecond;
u8 originalMinute;
u8 originalHour;


u8 num_8x16[][16] =
{
    {0xFF, 0xFF, 0xFF, 0xE7, 0xDB, 0xBD, 0xBD, 0xBD, 0xBD, 0xBD, 0xBD, 0xBD, 0xDB, 0xE7, 0xFF, 0xFF},/*"0",0*/
    {0xFF, 0xFF, 0xFF, 0xF7, 0xC7, 0xF7, 0xF7, 0xF7, 0xF7, 0xF7, 0xF7, 0xF7, 0xF7, 0xC1, 0xFF, 0xFF},/*"1",1*/
    {0xFF, 0xFF, 0xFF, 0xC3, 0xBD, 0xBD, 0xBD, 0xFD, 0xFB, 0xF7, 0xEF, 0xDF, 0xBD, 0x81, 0xFF, 0xFF},/*"2",2*/
    {0xFF, 0xFF, 0xFF, 0xC3, 0xBD, 0xBD, 0xFD, 0xFB, 0xE7, 0xFB, 0xFD, 0xBD, 0xBD, 0xC3, 0xFF, 0xFF},/*"3",3*/
    {0xFF, 0xFF, 0xFF, 0xFB, 0xF3, 0xF3, 0xEB, 0xDB, 0xDB, 0xBB, 0x80, 0xFB, 0xFB, 0xE0, 0xFF, 0xFF},/*"4",4*/
    {0xFF, 0xFF, 0xFF, 0x81, 0xBF, 0xBF, 0xBF, 0x87, 0xBB, 0xFD, 0xFD, 0xBD, 0xBB, 0xC7, 0xFF, 0xFF},/*"5",5*/
    {0xFF, 0xFF, 0xFF, 0xE7, 0xDB, 0xBF, 0xBF, 0xA3, 0x9D, 0xBD, 0xBD, 0xBD, 0xDD, 0xE3, 0xFF, 0xFF},/*"6",6*/
    {0xFF, 0xFF, 0xFF, 0x81, 0xBD, 0xFB, 0xFB, 0xF7, 0xF7, 0xEF, 0xEF, 0xEF, 0xEF, 0xEF, 0xFF, 0xFF},/*"7",7*/
    {0xFF, 0xFF, 0xFF, 0xC3, 0xBD, 0xBD, 0xBD, 0xDB, 0xE7, 0xDB, 0xBD, 0xBD, 0xBD, 0xC3, 0xFF, 0xFF},/*"8",8*/
    {0xFF, 0xFF, 0xFF, 0xC7, 0xBB, 0xBD, 0xBD, 0xBD, 0xB9, 0xC5, 0xFD, 0xFD, 0xDB, 0xE7, 0xFF, 0xFF},/*"9",9*/
    {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xE7, 0xE7, 0xFF, 0xFF, 0xFF, 0xFF, 0xE7, 0xE7, 0xFF, 0xFF} /*":",10*/
};

u8 num_6x12[][8] =
{
    {0x8F, 0x77, 0x77, 0x77, 0x77, 0x77, 0x77, 0x8F,},/*"0",0*/
    {0xDF, 0x9F, 0xDF, 0xDF, 0xDF, 0xDF, 0xDF, 0x8F},/*"1",1*/
    {0x8F, 0x77, 0x77, 0xEF, 0xDF, 0xBF, 0x7F, 0x07},/*"2",2*/
    {0x8F, 0x77, 0xF7, 0xCF, 0xF7, 0xF7, 0x77, 0x8F},/*"3",3*/
    {0xEF, 0xCF, 0xCF, 0xAF, 0x6F, 0x07, 0xEF, 0xC7},/*"4",4*/
    {0x07, 0x7F, 0x7F, 0x0F, 0x77, 0xF7, 0x77, 0x8F},/*"5",5*/
    {0xCF, 0xB7, 0x7F, 0x4F, 0x37, 0x77, 0x77, 0x8F},/*"6",6*/
    {0x87, 0xF7, 0xEF, 0xEF, 0xDF, 0xDF, 0xDF, 0xDF},/*"7",7*/
    {0x8F, 0x77, 0x77, 0x8F, 0x77, 0x77, 0x77, 0x8F},/*"8",8*/
    {0x8F, 0x77, 0x77, 0x67, 0x97, 0xF7, 0x6F, 0x9F}/*"9",9*/
};

u8 num_3x5[][5] = {
  {0x1F,0x5F,0x5F,0x5F,0x1F},//0
  {0xBF,0xBF,0xBF,0xBF,0xBF},//1
  {0x1F,0xDF,0x1F,0x7F,0x1F},//2
  {0x1F,0xDF,0x1F,0xDF,0x1F},//3
  {0x5F,0x5F,0x1F,0xDF,0xDF},//4
  {0x1F,0x7F,0x1F,0xDF,0x1F},//5
  {0x1F,0x7F,0x1F,0x5F,0x1F},//6
  {0x1F,0xDF,0xDF,0xDF,0xDF},//7
  {0x1F,0x5F,0x1F,0x5F,0x1F},//8
  {0x1F,0x5F,0x1F,0xDF,0x1F}//9
};

void set_3x5_number_local(u8 pos,u8 num)
{
  u8 a,b;
  u8 temp;
  if(pos == 1)
  {
    for(a=7,b=0;a<12;a++,b++)
    {
      temp = get_matrix_buf(a,4) | 0xE0;
      temp = temp & num_3x5[num][b];
      set_matrix_buf(a,4,temp);
    }
  }
  else
  {
    for(a=7,b=0;a<12;a++,b++)
    {
      temp = num_3x5[num][b] >> 4;
      temp = temp | 0xf1;
      temp = (get_matrix_buf(a,4) | 0x0E) & temp;
      set_matrix_buf(a,4,temp);
    }
  }
}

void set_6x12_number_local(u8 pos,u8 num) 
{
    u8 a,b;
    u8 temp;
    switch (pos) 
    {
        case 1:
            for (a = 4,b=0; a < 12; a++,b++)
            {
                temp = get_matrix_buf(a,0) & 0x03;
                temp = temp | num_6x12[num][b];
                set_matrix_buf(a,0,temp);//写入新数据
            }
        break;

        case 2:
            for (a = 4,b=0; a < 12; a++,b++) 
            {
                //判断num_6x12第8位是不是0
                if((num_6x12[num][b] >> 7) == 0)
                    temp = get_matrix_buf(a,0) & 0xfe;
                else
                    temp = get_matrix_buf(a,0) | 0x01;
               
                set_matrix_buf(a,0,temp);
                temp = (num_6x12[num][b] << 1) & 0xf8;//新数据后三位置0
                temp = (get_matrix_buf(a,1) & 0x07) | temp;//原始数据保留后三位
                set_matrix_buf(a,1,temp);
            }
            break;

        case 3:
            for (a = 4,b=0; a < 12; a++,b++)
            {
                temp = num_6x12[num][b] >> 2;
                temp = (get_matrix_buf(a,2) & 0xc0) | temp;
                set_matrix_buf(a,2,temp);
            }
            break;

        case 4:
            for (a = 4,b=0; a < 12; a++,b++)
            {
                temp = num_6x12[num][b] >> 1;
                temp = (get_matrix_buf(a,3) & 0x80) | temp;
                set_matrix_buf(a,3,temp);
            }
            break;
        default:break;
    }
}

/**
  函数功能：设置点阵某个8x16位置的字符，一般
  函数说明：只需调用即可实现消失或显示的效果。
            显示的位置已经固定
**/
void set_number_local(u8 local, u8 num) {
    if (local == 0 || local > 5) return;
    local--;
    for (u8 i = 0; i < 16; i++) {
        set_matrix_buf(i, local, num_8x16[num][i]);
    }
}

/**
  函数功能：中间两点的切换效果
  函数说明：只需调用即可实现消失或显示的效果。
            显示的位置已经固定
**/
void toggle_number_dot(void) {
    if (dot_flag == 1) {
        dot_flag = 0;
        set_matrix_buf(5, 2, 0xFF);
        set_matrix_buf(6, 2, 0xFF);
        set_matrix_buf(11, 2, 0xFF);
        set_matrix_buf(12, 2, 0xFF);
    } else {
        dot_flag = 1;
        set_matrix_buf(5, 2, 0xE7);
        set_matrix_buf(6, 2, 0xE7);
        set_matrix_buf(11, 2, 0xE7);
        set_matrix_buf(12, 2, 0xE7);
    }
}

void toggle_number_dot2() {
    if (dot_flag == 1) {
        dot_flag = 0;
        set_matrix_buf(5, 1,  get_matrix_buf(5,1) | 0x03);
        set_matrix_buf(6, 1,  get_matrix_buf(6,1) | 0x03);
        set_matrix_buf(9, 1, get_matrix_buf(9,1) | 0x03);
        set_matrix_buf(10, 1, get_matrix_buf(10,1) | 0x03);
    } else {
        dot_flag = 1;
        set_matrix_buf(5, 1,  get_matrix_buf(5,1) & 0xfc);
        set_matrix_buf(6, 1,  get_matrix_buf(6,1) & 0xfc);
        set_matrix_buf(9, 1, get_matrix_buf(9,1) & 0xfc);
        set_matrix_buf(10, 1, get_matrix_buf(10,1) & 0xfc);
    }
}

void anim_hhmmss_mode_update() {
    switch (time_update_flag) {
        case 6:
          set_6x12_number_local(1,matrix_time.hour_td);
        case 5:
          set_6x12_number_local(2,matrix_time.hour_sd);
        case 4:
          set_6x12_number_local(3,matrix_time.minute_td);
        case 3:
          set_6x12_number_local(4,matrix_time.minute_sd);
        case 2:
          set_3x5_number_local(1,matrix_time.second_td);
        case 1:
          set_3x5_number_local(2,matrix_time.second_sd);
        default:
            break;
    }
    is_can_move = 0;
}

/**
  函数功能：数字向上移动
  函数说明：变量x表示点阵屏幕上的哪一位数字，每次移动一行，变量dat表示新数据注入。
            在点阵中需要注入16次新数据，即移动16次，达到移动的动画效果
**/
void number_move_up(u8 x, u8 dat) {
    for (u8 y = 0; y < 15; y++)//0-15行数据整体向上移动
    {
        matrix_buf_data_up(y, x);
    }
    set_matrix_buf(15, x, dat);//最后一行数据注入新数据
}

/**
  函数功能：数字向下移动
  函数说明：变量x表示点阵屏幕上的哪一位数字，变量dat表示新数据注入。
            在点阵中需要注入16次新数据，即调用16次，达到移动的动画效果
**/
void number_move_down(u8 x, u8 dat) {
    for (s8 y = 15; y > 0; y--)//15-1行的数据整体向下移动
    {
        matrix_buf_data_down(y, x);
    }
    set_matrix_buf(0, x, dat);//第一行数据注入新数据
}


/**
  函数功能：“分秒”显示模式时，向上移动的动画
  函数说明：移动哪一位数字由switch的条件跳转决定，显示位置参数写死了
            需要调用16次，才能完成一个动画周期
**/
void anim_mmss_mode_move_up() {
    switch (time_update_flag) {
        case 6:
        case 5:
        case 4:
            number_move_up(0, num_8x16[matrix_time.minute_td][move_pos]);
        case 3:
            number_move_up(1, num_8x16[matrix_time.minute_sd][move_pos]);
        case 2:
            number_move_up(3, num_8x16[matrix_time.second_td][move_pos]);
        case 1:
            number_move_up(4, num_8x16[matrix_time.second_sd][move_pos]);
        default:
            break;
    }
    move_pos++;
    if (move_pos == 16) {
        move_pos = 0;
        is_can_move = 0;
    }
}

/**
  函数功能：“分秒”显示模式时，向下移动的动画
  函数说明：移动哪一位数字由switch的条件跳转决定，显示位置参数写死了
            需要调用16次，才能完成一个动画周期
**/
void anim_mmss_mode_move_down() {
    switch (time_update_flag) {
        case 6:
        case 5:
        case 4:
            number_move_down(0, num_8x16[matrix_time.minute_td][move_pos]);
        case 3:
            number_move_down(1, num_8x16[matrix_time.minute_sd][move_pos]);
        case 2:
            number_move_down(3, num_8x16[matrix_time.second_td][move_pos]);
        case 1:
            number_move_down(4, num_8x16[matrix_time.second_sd][move_pos]);
        default:
            break;
    }
    if (move_pos == 0) {
        move_pos = 15;
        is_can_move = 0;
    }
    move_pos--;
}

/**
  函数功能：“分秒”显示模式时，无动画的更新方式
  函数说明：移动哪一位数字由switch的条件跳转决定，显示位置参数写死了
            调用1次，即可改变数字，随后结束动画
**/
void anim_mmss_mode_update() {
    switch (time_update_flag) {
        case 6:
        case 5:
        case 4:
            set_number_local(1, matrix_time.minute_td);
        case 3:
            set_number_local(2, matrix_time.minute_sd);
        case 2:
            set_number_local(4, matrix_time.second_td);
        case 1:
            set_number_local(5, matrix_time.second_sd);
        default:
            break;
    }
    is_can_move = 0;
}


/**
  函数功能：“时分”显示模式时，向上移动的动画
  函数说明：移动哪一位数字由switch的条件跳转决定，显示位置参数写死了
            需要调用16次，才能完成一个动画周期
**/
void anim_hhmm_mode_move_up() {
    switch (time_update_flag) {
        case 6:
            number_move_up(0, num_8x16[matrix_time.hour_td][move_pos]);
        case 5:
            number_move_up(1, num_8x16[matrix_time.hour_sd][move_pos]);
        case 4:
            number_move_up(3, num_8x16[matrix_time.minute_td][move_pos]);
        case 3:
            number_move_up(4, num_8x16[matrix_time.minute_sd][move_pos]);
        default:
            break;
    }
    if (move_pos == 15) {
        move_pos = 0;
        is_can_move = 0;
    }
    move_pos++;
}

/**
  函数功能：“时分”显示模式时，向下移动的动画
  函数说明：移动哪一位数字由switch的条件跳转决定，显示位置参数写死了
            需要调用16次，才能完成一个动画周期
**/
void anim_hhmm_mode_move_down() {
    switch (time_update_flag) {
        case 6:
            number_move_down(0, num_8x16[matrix_time.hour_td][move_pos]);
        case 5:
            number_move_down(1, num_8x16[matrix_time.hour_sd][move_pos]);
        case 4:
            number_move_down(3, num_8x16[matrix_time.minute_td][move_pos]);
        case 3:
            number_move_down(4, num_8x16[matrix_time.minute_sd][move_pos]);
        default:
            break;
    }
    if (move_pos == 0) {
        move_pos = 15;
        is_can_move = 0;
    }
    move_pos--;
}

/**
  函数功能：“时分”显示模式时，无动画的更新方式
  函数说明：移动哪一位数字由switch的条件跳转决定，显示位置参数写死了
            调用1次，即可改变数字，随后结束动画
**/
void anim_hhmm_mode_update() {
    switch (time_update_flag) {
        case 6:
            set_number_local(1, matrix_time.hour_td);
        case 5:
            set_number_local(2, matrix_time.hour_sd);
        case 4:
            set_number_local(4, matrix_time.minute_td);
        case 3:
            set_number_local(5, matrix_time.minute_sd);
        default:
            break;
    }
    is_can_move = 0;
}


/**
  函数功能：秒计时
  函数说明：每调用一次，秒+1，自动增加时间并进位
  函数返回：返回1，秒的个位+1，但不进十位。返回2，秒的十位增加，但分不进位。以此类推
**/
u8 second_increases() {
    if (++matrix_time.second_sd != 10) return 1;//秒的个位
    matrix_time.second_sd = 0;

    if (++matrix_time.second_td != 6) return 2;//秒的十位
    matrix_time.second_td = 0;

    if (++matrix_time.minute_sd != 10) return 3;//分的个位
    matrix_time.minute_sd = 0;

    if (++matrix_time.minute_td != 6) return 4;//分的十位
    matrix_time.minute_td = 0;

    if (++matrix_time.hour_td == 2 && matrix_time.hour_sd < 4) return 5;//首先判断是否超过24小时
    else if (matrix_time.hour_td != 2 && matrix_time.hour_sd != 10) return 5;//小时的个位
    matrix_time.hour_sd = 0;

    if (++matrix_time.hour_td == 3) matrix_time.hour_td = 0;//小时的十位
    return 6;
}

/*
  函数说明：计时、倒计时初始化
*/
void timing_init(void)
{
    dot_toggle = 0;//关闭点闪烁
    timingPause = 0;//关闭暂停计时
    time_update_flag = 6;//清除计时标志
    dot_flag = 0;//显示时间点
    if(clockMode == CLOCK_HHMMSS)
      toggle_number_dot2();
    else
      toggle_number_dot();
}

/*
  函数说明：计时、倒计时按键按下时的处理函数
*/
void timing_key_handle(u8 m)
{
    if(time_update_flag == 0xff)
    {
        timingPause = 0;
        time_update_flag = 6;
        if(m == MODE_TIMING_2 || m == MODE_TIMING_3)
        {
            set_clock_time(0,0,0);
        }
        else
        {
            clockSecond = originalSecond;
            clockMinute = originalMinute;
            clockHour = originalHour;
            set_clock_time(clockHour,clockMinute,clockSecond);  
        }
    }
    else
    {
        timingPause = timingPause==0?1:0;
    }
}

/**
  函数功能：正计时
  函数说明：每调用一次，秒+1，最多计时99分钟59秒
  函数返回：返回1，秒的个位+1，但不进十位。返回2，秒的十位增加，但分不进位。以此类推
**/

u8 positive_timing()
{
    if(clockSecond == 59)
    {
        if(clockMode == CLOCK_HHMMSS)
        {
            if (clockMinute == 59)
            {
                if(clockHour == 99) return 0xff;
                clockHour++;
                clockMinute = 0;
                clockSecond = 0;
                matrix_time.hour_td = clockHour / 10;
                matrix_time.hour_sd = clockHour % 10;
                matrix_time.minute_td = 0;
                matrix_time.minute_sd = 0;
                matrix_time.second_td = 0;
                matrix_time.second_sd = 0;
                return matrix_time.hour_sd == 0 ? 6 : 5;
            }
        }
        else
        {
            if(clockMinute == 99) return 0xff;
        }
        
        clockMinute++;
        clockSecond = 0;
        matrix_time.minute_td = clockMinute / 10;
        matrix_time.minute_sd = clockMinute % 10;
        matrix_time.second_td = 0;
        matrix_time.second_sd = 0;
        return matrix_time.minute_sd == 0 ? 4 : 3;
    }
    else
    {
        clockSecond++;
        matrix_time.second_td = clockSecond / 10;
        matrix_time.second_sd = clockSecond % 10;
        return matrix_time.second_sd == 0 ? 2 : 1;
    }
}

/**
  函数功能：倒计时
  函数说明：每调用一次，秒-1，最多倒计时99分钟59秒
  函数返回：返回1，秒的个位+1，但不进十位。返回2，秒的十位增加，但分不进位。以此类推
**/
u8 countdown_timing()
{
    if(clockSecond == 0)
    {
        if (clockMinute == 0)
        {
            if(clockMode == CLOCK_MMSS) return 0xff;
            if(clockHour == 0) return 0xff;
            clockHour--;
            clockMinute = 59;
            clockSecond = 59;
            matrix_time.hour_td = clockHour / 10;
            matrix_time.hour_sd = clockHour % 10;
            matrix_time.minute_td = 5;
            matrix_time.minute_sd = 9;
            matrix_time.second_td = 5;
            matrix_time.second_sd = 9;
            return matrix_time.hour_sd == 9 ? 6 : 5;
        }
        else
        {
            clockMinute--;
            clockSecond = 59;
            matrix_time.minute_td = clockMinute / 10;
            matrix_time.minute_sd = clockMinute % 10;
            matrix_time.second_td = 5;
            matrix_time.second_sd = 9;
            return matrix_time.minute_sd == 9 ? 4 : 3;
        }
    }
    else
    {
        clockSecond--;
        matrix_time.second_td = clockSecond / 10;
        matrix_time.second_sd = clockSecond % 10;
        return matrix_time.second_sd == 9 ? 2 : 1;
    }
}

/**
  函数功能：正计时处理函数，由定时器调用
**/
void monitor_timing(void)
{
    if(timingPause) return;
    if(time_update_flag == 0xff) return;
    time_update_flag = positive_timing();
    move_pos = anim_update_pos;
    is_can_move = 1;
}

/**
  函数功能：倒计时处理函数，由定时器调用
**/
void monitor_countdown(void)
{
    if(timingPause) return;
    if(time_update_flag == 0xff) return;
    time_update_flag = countdown_timing();
    move_pos = anim_update_pos;
    is_can_move = 1;
}

/**
  函数功能：时钟处理函数。该函数一秒调用一次，由定时器调用
**/
void monitor_time(void) {
    time_update_flag = second_increases();
    if (clockMode == CLOCK_HHMM) {
        if (time_update_flag > 2) {//时分显示模式下，秒没有更新，所以没有动画
            move_pos = anim_update_pos;
            is_can_move = 1;
        }
    } else if (clockMode == CLOCK_MMSS) {
        move_pos = anim_update_pos;
        is_can_move = 1;
    } else if (clockMode == CLOCK_HHMMSS){
        is_can_move = 1;
    }else{
        is_can_move = 0;
    }
}

/**
  函数功能：动画监听，每25ms调用一次
  函数说明：该函数用于实现动画效果
**/
void monitor_anim(void) {
    if (is_can_move == 1)//判断是否可以播放动画
    {
        anim_update_function();
    }
    //判断是否显示时间的点
    if(dot_toggle == 0) return;
    dot_count++;
    if (dot_count == 20) {
        dot_count = 0;
        anim_dot_update_function();
    }
}

/*
  函数说明：设置时钟显示的更新动画
*/
void change_clock_anim(u8 clock_mode, u8 anim_mode)
{
    is_can_move = 0;
    anim_update_pos = (anim_mode == CLOCK_ANIM_UP) ? 0 : 15;
    if (clock_mode == CLOCK_MMSS) { //分秒显示
        if (anim_mode == CLOCK_ANIM_UP) {
            anim_update_function = anim_mmss_mode_move_up;
        } else if (anim_mode == CLOCK_ANIM_DOWN) {
            anim_update_function = anim_mmss_mode_move_down;
        } else {
            anim_update_function = anim_mmss_mode_update;
        }
        anim_dot_update_function = toggle_number_dot;
    } else if (clock_mode == CLOCK_HHMM) { //时分显示
        if (anim_mode == CLOCK_ANIM_UP) {
            anim_update_function = anim_hhmm_mode_move_up;
        } else if (anim_mode == CLOCK_ANIM_DOWN) {
            anim_update_function = anim_hhmm_mode_move_down;
        } else {
            anim_update_function = anim_hhmm_mode_update;
        }
        anim_dot_update_function = toggle_number_dot;
    }else if(clock_mode == CLOCK_HHMMSS){
        anim_update_function = anim_hhmmss_mode_update;
        anim_dot_update_function = toggle_number_dot2;
    }
}

/**
  函数功能：设置时钟显示的模式，以及动画
**/
void set_clock_mode(u8 clock_mode, u8 anim_mode) {
    clockMode = clock_mode;
    memset(matrix_buf,0xff,80);
    change_clock_anim(clock_mode,anim_mode);
}

/**
  函数功能：设置时间，时分秒
**/
void set_clock_time(u8 hour, u8 minute, u8 second)
{
    matrix_time.hour_td = hour / 10;
    matrix_time.hour_sd = hour % 10;
    matrix_time.minute_td = minute / 10;
    matrix_time.minute_sd = minute % 10;
    matrix_time.second_td = second / 10;
    matrix_time.second_sd = second % 10;
    switch(clockMode)
    {
      case CLOCK_MMSS:
        set_number_local(1, matrix_time.minute_td);
        set_number_local(2, matrix_time.minute_sd);
        //set_number_local(3, 10);
        set_number_local(4, matrix_time.second_td);
        set_number_local(5, matrix_time.second_sd);
      break;
      case CLOCK_HHMM:
        set_number_local(1, matrix_time.hour_td);
        set_number_local(2, matrix_time.hour_sd);
        //set_number_local(3, 10);
        set_number_local(4, matrix_time.minute_td);
        set_number_local(5, matrix_time.minute_sd);
      break;
      case CLOCK_HHMMSS:
        set_6x12_number_local(1,matrix_time.hour_td);
        set_6x12_number_local(2,matrix_time.hour_sd);
        set_6x12_number_local(3,matrix_time.minute_td);
        set_6x12_number_local(4,matrix_time.minute_sd);
        set_3x5_number_local(1,matrix_time.second_td);
        set_3x5_number_local(2,matrix_time.second_sd);
      break;
      default:break;
    }
}
