#ifndef __NTP_TIME_H
#define __NTP_TIME_H

#include <Arduino.h>

void ntp_time_init();
u32 get_ntp_time();

#endif
