#include <ESP8266WiFi.h>
#include <EEPROM.h>
#include <DNSServer.h>
#include <ESP8266WebServer.h>
#include "ConnectWiFi.h"
#include "InfoPrint.h"

struct WifiConfigInfo
{
  char ssid[32];
  char password[64];
} wifiConfig;


IPAddress apIP(192, 168, 4, 1);//ESP8266配网IP地址
DNSServer dnsServer;
ESP8266WebServer server(80);
bool isRunning = false;
const char* page_html = HTML;

//保存Wifi信息
void saveWifiConfig()
{
  EEPROM.begin(128);//向系统申请128b ROM
  uint8_t *p = (uint8_t*)(&wifiConfig);//开始写入
  for (int i = 0; i < sizeof(wifiConfig); i++)
  {
    EEPROM.write(i, *(p + i)); //在闪存内模拟写入
  }
  EEPROM.commit();//执行写入ROM
  delay(500);
}

//读取Wifi信息
void loadWifiConfig()
{
  EEPROM.begin(128);
  uint8_t *p = (uint8_t*)(&wifiConfig);
  for (int i = 0; i < sizeof(wifiConfig); i++)
  {
    *(p + i) = EEPROM.read(i);
  }
  EEPROM.commit();
  delay(500);
}

//等待wifi连接成功
bool waittingConnection(void)
{
  char count = 0;
  INFO.println("Start Connect To Wifi");
  while(WiFi.isConnected() == false)//等待连接成功
  {
    delay(500);
    count++;
    if(count > 20)//如果超时没连上，就开启Web配网 可适当调整这个时间
    {
      break;
    }
    INFO.print('.');
  }
  //返回连接成功的状态
  return WiFi.isConnected();
}

//访问主页回调函数
void handlerPageHtml(void)
{
  server.send(200, "text/html", page_html);
}

//处理用户传递过来的ssid和password 的函数
void handlerArgsRequest(void)
{
  //判断是否有账号参数
  if (server.hasArg("ssid") && server.hasArg("password")) 
  {
    //将账号密码参数拷贝到wifiConfig中
    strcpy(wifiConfig.ssid, server.arg("ssid").c_str());
    strcpy(wifiConfig.password, server.arg("password").c_str());
    server.send(200, "text/html", "<meta charset='UTF-8'>保存成功，即将连接WIFI");
  }
  else 
  {
    //没有参数
    INFO.println("error,ssid or password is empty");
    server.send(200, "text/html", "<meta charset='UTF-8'>error,ssid or password is empty");//返回错误页面
    return;
  }
  
  delay(500);

  //连接wifi
  WiFi.mode(WIFI_STA);
  WiFi.begin(wifiConfig.ssid,wifiConfig.password);
  if(waittingConnection())
  {
    server.stop();
    isRunning = false;
    saveWifiConfig();
    WiFi.setAutoConnect(true);//设置自动连接
    INFO.println("WIFI Connect Success!");
  }
}

//初始化wifi配网
void initNetworkAdapter(void)
{
  //初始化AP模式
  WiFi.mode(WIFI_AP);
  WiFi.hostname("ESP8266-NTP-CLOCK");//设置ESP8266设备名
  WiFi.softAPConfig(apIP, apIP, IPAddress(255, 255, 255, 0));
  if(WiFi.softAP("ESP8266-NTP-CLOCK")) INFO.println("Start WIFI_AP");
  
  //初始化WebServer
  server.on("/", HTTP_GET, handlerPageHtml);//设置主页回调函数
  server.onNotFound(handlerPageHtml);//设置无法响应的http请求的回调函数
  server.on("/", HTTP_POST, handlerArgsRequest);//设置Post请求回调函数
  server.begin();//启动WebServer
  INFO.println("Start WebServer!");

  //初始化DNS服务器
  if(dnsServer.start(53, "*", apIP))
    INFO.println("Start DNS Server!");
  else
    INFO.println("Start DNS Server Failed");
}

//监听网页提交的数据
void listenerWiFiServer(void)
{
  isRunning = true;
  pinMode(2,OUTPUT);
  while(isRunning)
  {
    server.handleClient();
    dnsServer.processNextRequest();
    digitalWrite(2,HIGH);delay(50);
    digitalWrite(2,LOW);delay(50);
  }
  digitalWrite(2,HIGH);
}

//启动配网
void start_network_adapter()
{
  initNetworkAdapter();//启动配网功能
  listenerWiFiServer();//监听配网提交的数据
}

//初始化设备的wifi连接，若连接失败，自动打开配网模式
void wifi_init()
{
  if(WiFi.isConnected()) return;
  WiFi.mode(WIFI_STA);//切换为STA模式
  loadWifiConfig();//加载保存的wifi信息
  WiFi.begin(wifiConfig.ssid,wifiConfig.password);//尝试连接wifi
  if(waittingConnection())
  {
    INFO.println("WIFI Connect Success!");
    return;
  }
  
  //如果连接失败，启动配网
  start_network_adapter();
}
