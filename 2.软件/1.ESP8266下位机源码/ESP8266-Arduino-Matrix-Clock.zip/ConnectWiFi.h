#ifndef __CONNECTWIFI_H_
#define __CONNECTWIFI_H_

//配网页面代码
#define HTML  "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport'content='width=device-width, initial-scale=1.0'><title>连接WiFi</title></head><body><form name='input'action='/'method='POST'><b>连接WiFi</b><br>WiFi名称:<br><input type='text'name='ssid'><br><br>WiFi密码:<br><input type='text'name='password'><br><br><input type='submit'value='保存'></form></body></html>"

void wifi_init(void);
void start_network_adapter();
#endif
