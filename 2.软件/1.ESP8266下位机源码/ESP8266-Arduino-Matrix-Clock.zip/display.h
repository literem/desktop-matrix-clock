#ifndef __DISPLAY_H
#define __DISPLAY_H

#include "matrix_config.h"

void set_display_mode(u8 m);
void set_display_args(u8 m,u16 value);
void key_init();
void display_init();

extern u8 currentClockMode;
extern void (*displaying)(void);

#endif
