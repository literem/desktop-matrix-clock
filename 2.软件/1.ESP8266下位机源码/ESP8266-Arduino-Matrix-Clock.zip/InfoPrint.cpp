#include "InfoPrint.h"
#include "HardwareSerial.h"
#define IS_PRINT
class StateInfoPrint INFO;

uint8_t request_array[9];

void StateInfoPrint::init(void)
{
  Serial.begin(9600);
  request_array[0] = 0xff;
  request_array[1] = 0xff;
  request_array[7] = 0xff;
  request_array[8] = 0xff;
  request_array[2] = 9;
  request_array[3] = 0xA3;
}

void StateInfoPrint::print(char *info)
{
  #ifdef IS_PRINT
  Serial.print(info);
  #endif
}

void StateInfoPrint::print(char ch)
{
  #ifdef IS_PRINT
  Serial.print(ch);
  #endif
}

void StateInfoPrint::println(char *info)
{
  #ifdef IS_PRINT
  Serial.println(info);
  #endif
}

/*
  函数说明：发送请求帧
  参数说明： frame_count，一共多少帧
           frame_index，当前请求哪一帧
           frame_id，帧ID
*/
void StateInfoPrint::requestFrame(u8 frame_count,u8 frame_index,u8 frame_id)
{
  request_array[4] = frame_count;
  request_array[5] = frame_index;
  request_array[6] = frame_id;
  Serial.write(request_array,9);
}

/*
  函数说明：发送结束帧
  参数说明：frame_id，帧ID
*/
void StateInfoPrint::finishFrame(u8 frame_id)
{
  request_array[4] = 0;
  request_array[5] = 0;
  request_array[6] = frame_id;
  Serial.write(request_array,9);
}
