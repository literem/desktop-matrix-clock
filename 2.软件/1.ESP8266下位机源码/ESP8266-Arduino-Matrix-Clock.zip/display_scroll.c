#include "display_scroll.h"
#include "scanning.h"

u8 scroll_buf[20][32];
matrix_line_t *matrixLine;

u16 scrollMaxCound;
u16 scrollIndex;
u16 scrollEndIndex;

/*
  函数说明：向左移1bit
  参数说明：buf：数组指针，即要从数组哪一个地址的数据开始移动
          newData：移动后右边补的新数据，1bit
*/
void leftShiftOne(u8 *buf,u8 newData)
{
    matrix_line_t *matrixLine = (matrix_line_t*) buf;
    matrixLine->ch1.num <<= 1;
    matrixLine->ch1.bit0 = matrixLine->ch2.bit7;

    matrixLine->ch2.num <<= 1;
    matrixLine->ch2.bit0 = matrixLine->ch3.bit7;

    matrixLine->ch3.num <<= 1;
    matrixLine->ch3.bit0 = matrixLine->ch4.bit7;

    matrixLine->ch4.num <<= 1;
    matrixLine->ch4.bit0 = matrixLine->ch5.bit7;

    matrixLine->ch5.num <<= 1;
    matrixLine->ch5.bit0 = newData & 0x01;
}

/*
  函数说明：滚动显示初始化
*/
void scroll_init(u8 count)
{
  scrollIndex = 0;
  scrollMaxCound = count * 16;
  scrollEndIndex = scrollMaxCound + 32;
}

/*
  函数说明：滚动显示功能函数，由定时器调用
*/
void monitor_scroll()
{
    if(scrollIndex >= scrollMaxCound)
    {
        if(scrollIndex == scrollEndIndex)
        {
            scrollIndex = 0;
        }
        else
        {
            for (u8 i = 0; i < 16; i++)
            {
                leftShiftOne(&matrix_buf[i][0],1);
            }
            scrollIndex++;
            return;
        }
    }
    u8 pos = scrollIndex / 16;//计算出处于哪一个字
    u8 n = 7 - (scrollIndex % 8);
    u8 offset = (scrollIndex / 8) % 2;//计算是在左8bit还是右8bit
    for (u8 i = 0; i < 16; i++,offset+=2)
    {
        leftShiftOne(&matrix_buf[i][0],scroll_buf[pos][offset] >> n);
    }
    scrollIndex++;
}
