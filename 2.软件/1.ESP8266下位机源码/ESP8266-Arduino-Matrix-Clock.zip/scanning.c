#include "scanning.h"
#include <string.h>
#include "matrix_config.h"
#include "platform_esp8266.h"

u8 matrix_buf[16][5];
static s8 ii,jj;

/*
  函数说明：74HC138行扫描
  参数说明：row：0 - 15行
*/
void scanning_row(u8 row)
{
    if( row       & 0x01) A1_HIGH(); else A1_LOW();
    if((row >> 1) & 0x01) A2_HIGH(); else A2_LOW();
    if((row >> 2) & 0x01) A3_HIGH(); else A3_LOW();
    if((row >> 3) & 0x01) A4_HIGH(); else A4_LOW();
}

/*
  函数说明：74HC595列扫描，一次发送8bit数据
*/
void send_column(u8 dat)
{
  for(u8 i=0;i<8;i++)
  {
    if(dat&0x01) 
      SER_HIGH();
	  else
	    SER_LOW();
    CLK_HIGH();
	  dat>>=1;
    NOP();
    CLK_LOW();
  }
  RCK_HIGH()
  NOP();
  RCK_LOW();
}

/*
  函数说明：清空列，发送40bit的数据到74HC595
*/
void clean_column()
{
  SER_HIGH(); 
  for(u8 i=0;i<40;i++)
  {
      CLK_HIGH();
      NOP();
      CLK_LOW();
  }
  RCK_HIGH()
  NOP();
  RCK_LOW();
}

/*
  函数说明：清空扫描缓冲数组
*/
void clean_matrix_buf()
{
    memset(&matrix_buf[0][0],0xff,80);
}

/*
  函数说明：扫描一帧画面，即扫描16行
*/
void scan_one_frame()
{
    for(ii=0;ii<16;ii++)
    {
        HC138_Disable();
        for(jj=4;jj>=0;jj--)
        {
            send_column(matrix_buf[ii][jj]);
        }
        scanning_row(ii);
        HC138_Enable();
        delay_us(800);
    }
}

/************ 测试行列扫描，未使用到以下函数 ****************/
#ifdef SCANNING_TEST
#define DelayTime   300
u8 p[5];
u8 last_pos = 0;
void set_dot_pos(u8 pos)
{
    u8 cpos = pos / 8;
    u8 bit = 7 - (pos % 8);
    p[cpos] = ~(1<<bit);
    
    if(last_pos != cpos)
    {
        p[last_pos] = 0xff;
        last_pos = cpos;
    }
}

void send_dot_pos()
{
    for(s8 i=4;i>=0;i--)
    {
        send_column(p[i]);
    }
}

//扫描横向点测试
void scanning_test_hor_dot(void)
{
    s8 a,b;
    for(b=0;b<16;b++)
    {
        scanning_row(b);
        for(a=0;a<40;a++)
        {
            set_dot_pos(a);
            send_dot_pos();
            HC138_Enable();
            delay_ms(DelayTime);
            HC138_Disable();
        }
        
        b++;
        scanning_row(b);
        for(a=39;a>=0;a--)
        {
            set_dot_pos(a);
            send_dot_pos();
            HC138_Enable();
            delay_ms(DelayTime);
            HC138_Disable();
        }
    }
    
    for(b=15;b>=0;b--)
    {
        scanning_row(b);
        for(a=0;a<40;a++)
        {
            set_dot_pos(a);
            send_dot_pos();
            HC138_Enable();
            delay_ms(DelayTime);
            HC138_Disable();
        }
        
        b--;
        scanning_row(b);
        for(a=39;a>=0;a--)
        {
            set_dot_pos(a);
            send_dot_pos();
            HC138_Enable();
            delay_ms(DelayTime);
            HC138_Disable();
        }
    }
}

//扫描纵向点测试
void scanning_test_ver_dot(void)
{
    s8 a,b;
    for(a=0;a<40;a++)
    {
        HC138_Disable();
        set_dot_pos(a);
        send_dot_pos();
        scanning_row(0);
        HC138_Enable();
        for(b=1;b<16;b++)
        {
            scanning_row(b);
            delay_ms(DelayTime);
        }
        
        a++;
        HC138_Disable();
        set_dot_pos(a);
        send_dot_pos();
        scanning_row(15);
        HC138_Enable();
        for(b=14;b>=0;b--)
        {
            scanning_row(b);
            delay_ms(DelayTime);
        }
    }
    
    for(a=39;a>=0;a--)
    {
        HC138_Disable();
        set_dot_pos(a);
        send_dot_pos();
        scanning_row(0);
        HC138_Enable();
        for(b=0;b<16;b++)
        {
            scanning_row(b);
            delay_ms(DelayTime);
        }
		
        a--;
        HC138_Disable();
        set_dot_pos(a);
        send_dot_pos();
        scanning_row(15);
        HC138_Enable();
        for(b=15;b>=0;b--)
        {
            scanning_row(b);
            delay_ms(DelayTime);
        }
    }
}

void scanning_dot_test()
{
    memset(p,0xff,sizeof(p));
    scanning_test_hor_dot();
    scanning_test_ver_dot();
}

#endif
